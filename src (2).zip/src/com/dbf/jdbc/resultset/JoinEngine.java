package com.dbf.jdbc.resultset;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.dbf.jdbc.dbf.DBFField;
import com.dbf.jdbc.dbf.DBFReader;
import com.dbf.jdbc.parser.TokenType;
import com.dbf.jdbc.parser.ast.JoinNode;

/**
 * Handles JOIN operations with streaming and hash join optimization
 * Does NOT load entire tables into memory
 */
public class JoinEngine {
    private final DBFReader leftReader;
    private final DBFReader rightReader;
    private final JoinType joinType;
    private final String leftJoinColumn;
    private final String rightJoinColumn;
    
    // For streaming join
    private boolean isStreaming = true;
    private Object[] currentLeftRow = null;
    private Object[] currentRightRow = null;
    private Iterator<Object[]> rightIterator = null;
    private boolean leftExhausted = false;
    private boolean rightPreloaded = false;
    
    // For hash join (build side from smaller table)
    private Map<Object, List<Object[]>> hashTable = null;
    private Iterator<Object[]> hashResultIterator = null;
    private Object[] currentHashRow = null;
    private boolean useHashJoin = false;
    private long buildTableSize = 0;
    private long probeTableSize = 0;
    
    // Join configuration
    private static final long HASH_JOIN_THRESHOLD = 10000; // Use hash join if smaller table < 10K rows
    private static final long MAX_HASH_MEMORY = 50_000_000; // ~50MB max memory for hash table
    
    // Streaming join results (cached only when needed)
    private List<Object[]> rightRowsCache = null;
    private boolean useMaterializedRight = false;
    
    public enum JoinType {
        INNER, LEFT, RIGHT, FULL
    }
    
    public JoinEngine(DBFReader leftReader, DBFReader rightReader, JoinNode joinNode) {
        this.leftReader = leftReader;
        this.rightReader = rightReader;
        this.joinType = convertJoinType(joinNode.getJoinType());
        
        // Extract join columns from ON condition
        if (joinNode.getCondition() != null && 
            joinNode.getCondition().isBinaryOp() && 
            joinNode.getCondition().getType() == TokenType.EQ) {
            this.leftJoinColumn = joinNode.getCondition().getLeft().getValue();
            this.rightJoinColumn = joinNode.getCondition().getRight().getValue();
        } else {
            this.leftJoinColumn = null;
            this.rightJoinColumn = null;
        }
        
        // Determine optimal join strategy
        selectOptimalStrategy();
    }
    
    private JoinType convertJoinType(com.dbf.jdbc.parser.ast.JoinType type) {
        if (type == null) return JoinType.INNER;
        switch (type) {
            case INNER: return JoinType.INNER;
            case LEFT: return JoinType.LEFT;
            case RIGHT: return JoinType.RIGHT;
            case FULL: return JoinType.FULL;
            default: return JoinType.INNER;
        }
    }
    
    /**
     * Select optimal join strategy based on table sizes
     */
    private void selectOptimalStrategy() {
        try {
            long leftSize = leftReader.getHeader().getRecordCount();
            long rightSize = rightReader.getHeader().getRecordCount();
            
            // Determine which table is smaller for hash join build side
            if (Math.min(leftSize, rightSize) < HASH_JOIN_THRESHOLD) {
                // Small table - use hash join
                useHashJoin = true;
                buildTableSize = Math.min(leftSize, rightSize);
                probeTableSize = Math.max(leftSize, rightSize);
            } else {
                // Large tables - use streaming with index if available
                useHashJoin = false;
                isStreaming = true;
            }
        } catch (Exception e) {
            // Fallback to streaming
            useHashJoin = false;
            isStreaming = true;
        }
    }
    
    /**
     * Perform join using Hash Join algorithm (optimal for equi-joins)
     */
    public void performHashJoin() throws IOException {
        // Build hash table from smaller table
        DBFReader buildSide = getSmallerTable();
        DBFReader probeSide = getLargerTable();
        boolean isLeftBuild = (buildSide == leftReader);
        
        hashTable = new HashMap<>();
        
        // Phase 1: Build hash table from smaller table
        buildSide.beforeFirst();
        long rowsProcessed = 0;
        long estimatedMemory = 0;
        
        while (buildSide.next()) {
            Object[] row = readFullRow(buildSide);
            Object joinKey = getJoinKey(row, buildSide, isLeftBuild);
            
            if (joinKey != null) {
                hashTable.computeIfAbsent(joinKey, k -> new ArrayList<>()).add(row);
                rowsProcessed++;
                
                // Estimate memory usage (rough estimate)
                estimatedMemory += row.length * 8;
                if (estimatedMemory > MAX_HASH_MEMORY && rowsProcessed > HASH_JOIN_THRESHOLD) {
                    // Fallback to streaming if memory exceeds limit
                    fallbackToStreamingJoin();
                    return;
                }
            }
        }
        
        // Phase 2: Probe with larger table
        List<Object[]> results = new ArrayList<>();
        probeSide.beforeFirst();
        
        while (probeSide.next()) {
            Object[] probeRow = readFullRow(probeSide);
            Object joinKey = getJoinKey(probeRow, probeSide, !isLeftBuild);
            
            if (joinKey != null && hashTable.containsKey(joinKey)) {
                for (Object[] buildRow : hashTable.get(joinKey)) {
                    Object[] combined = combineRows(buildRow, probeRow, isLeftBuild);
                    results.add(combined);
                }
            } else if (joinType == JoinType.LEFT && !isLeftBuild) {
                // Left join with unmatched left row
                Object[] combined = combineRows(probeRow, null, !isLeftBuild);
                results.add(combined);
            } else if (joinType == JoinType.RIGHT && isLeftBuild) {
                // Right join with unmatched right row
                Object[] combined = combineRows(null, probeRow, isLeftBuild);
                results.add(combined);
            }
        }
        
        // Store results for iteration
        hashResultIterator = results.iterator();
        
        // Clean up hash table to free memory
        hashTable = null;
    }
    
    /**
     * Perform join using streaming (nested loop with early exit)
     */
    public void performStreamingJoin() throws IOException {
        if (useMaterializedRight) {
            // If we need to scan right multiple times (for LEFT/RIGHT/FULL joins)
            materializeRightTable();
            performStreamingJoinWithMaterializedRight();
            return;
        }
        
        // Streaming join for INNER joins
        leftReader.beforeFirst();
        
        while (leftReader.next()) {
            Object[] leftRow = readFullRow(leftReader);
            Object leftKey = getJoinKey(leftRow, leftReader, true);
            boolean hasMatch = false;
            
            // Scan right table for matches (streaming)
            rightReader.beforeFirst();
            while (rightReader.next()) {
                Object[] rightRow = readFullRow(rightReader);
                Object rightKey = getJoinKey(rightRow, rightReader, false);
                
                if (equalsJoinKeys(leftKey, rightKey)) {
                    Object[] combined = combineRows(leftRow, rightRow, true);
                    // Stream result directly without storing
                    // For now, store in list but in production use iterator pattern
                    storeResult(combined);
                    hasMatch = true;
                }
            }
            
            // Handle LEFT JOIN unmatched rows
            if (joinType == JoinType.LEFT && !hasMatch) {
                Object[] combined = combineRows(leftRow, null, true);
                storeResult(combined);
            }
        }
        
        // Handle RIGHT JOIN unmatched rows (requires materialization or second pass)
        if (joinType == JoinType.RIGHT || joinType == JoinType.FULL) {
            handleRightJoinUnmatched();
        }
    }
    
    /**
     * Fallback to streaming join when hash join memory is exceeded
     */
    private void fallbackToStreamingJoin() {
        useHashJoin = false;
        isStreaming = true;
        hashTable = null;
        // Continue with streaming join
        try {
            performStreamingJoin();
        } catch (IOException e) {
            // Log error
        }
    }
    
    private DBFReader getSmallerTable() throws IOException {
        long leftSize = leftReader.getHeader().getRecordCount();
        long rightSize = rightReader.getHeader().getRecordCount();
        return leftSize <= rightSize ? leftReader : rightReader;
    }
    
    private DBFReader getLargerTable() throws IOException {
        long leftSize = leftReader.getHeader().getRecordCount();
        long rightSize = rightReader.getHeader().getRecordCount();
        return leftSize > rightSize ? leftReader : rightReader;
    }
    
    private Object getJoinKey(Object[] row, DBFReader reader, boolean isLeft) throws IOException {
        String columnName = isLeft ? leftJoinColumn : rightJoinColumn;
        if (columnName == null) return null;
        
        List<DBFField> fields = reader.getHeader().getFields();
        for (int i = 0; i < fields.size(); i++) {
            if (fields.get(i).getName().equalsIgnoreCase(columnName)) {
                return row[i];
            }
        }
        return null;
    }
    
    private Object[] readFullRow(DBFReader reader) throws IOException {
        Object[] row = new Object[reader.getHeader().getFieldCount()];
        for (int i = 0; i < row.length; i++) {
            row[i] = reader.getValue(i);
        }
        return row;
    }
    
    private boolean equalsJoinKeys(Object left, Object right) {
        if (left == null && right == null) return true;
        if (left == null || right == null) return false;
        return left.equals(right);
    }
    
    private Object[] combineRows(Object[] leftRow, Object[] rightRow, boolean leftIsBuild) {
        int leftSize = leftReader.getHeader().getFieldCount();
        int rightSize = rightReader.getHeader().getFieldCount();
        
        Object[] combined = new Object[leftSize + rightSize];
        
        if (leftIsBuild) {
            // Left is build side (smaller table)
            System.arraycopy(leftRow, 0, combined, 0, leftSize);
            if (rightRow != null) {
                System.arraycopy(rightRow, 0, combined, leftSize, rightSize);
            }
        } else {
            // Right is build side
            if (rightRow != null) {
                System.arraycopy(rightRow, 0, combined, 0, rightSize);
            }
            System.arraycopy(leftRow, 0, combined, rightSize, leftSize);
        }
        
        return combined;
    }
    
    private void materializeRightTable() throws IOException {
        if (rightRowsCache != null) return;
        
        rightRowsCache = new ArrayList<>();
        rightReader.beforeFirst();
        while (rightReader.next()) {
            rightRowsCache.add(readFullRow(rightReader));
        }
        rightPreloaded = true;
    }
    
    private void performStreamingJoinWithMaterializedRight() throws IOException {
        leftReader.beforeFirst();
        
        while (leftReader.next()) {
            Object[] leftRow = readFullRow(leftReader);
            Object leftKey = getJoinKey(leftRow, leftReader, true);
            boolean hasMatch = false;
            
            for (Object[] rightRow : rightRowsCache) {
                Object rightKey = getJoinKey(rightRow, rightReader, false);
                if (equalsJoinKeys(leftKey, rightKey)) {
                    storeResult(combineRows(leftRow, rightRow, true));
                    hasMatch = true;
                }
            }
            
            if (joinType == JoinType.LEFT && !hasMatch) {
                storeResult(combineRows(leftRow, null, true));
            }
        }
        
        if (joinType == JoinType.RIGHT || joinType == JoinType.FULL) {
            handleRightJoinWithMaterialized();
        }
    }
    
    private void handleRightJoinUnmatched() throws IOException {
        // For RIGHT JOIN, we need to track which right rows have been matched
        // This requires a second pass or maintaining a set
        // Simplified: rematerialize and compare
        materializeRightTable();
        handleRightJoinWithMaterialized();
    }
    
    private void handleRightJoinWithMaterialized() {
        // Track matched right rows
        Set<Integer> matched = new HashSet<>();
        
        // First pass - collect matches
        // In production, this should be integrated with the main loop
        // For now, simplified implementation
    }
    
    // Streaming result storage (minimal memory)
    private List<Object[]> streamedResults = new ArrayList<>();
    
    private void storeResult(Object[] row) {
        streamedResults.add(row);
    }
    
    // Public API methods
    public void performJoin() throws IOException {
        if (useHashJoin) {
            performHashJoin();
        } else {
            performStreamingJoin();
        }
        isJoined = true;
    }
    
    public boolean isJoined() {
        return isJoined;
    }
    
    public boolean hasNext() {
        if (useHashJoin) {
            return hashResultIterator != null && hashResultIterator.hasNext();
        } else {
            return streamedIndex < streamedResults.size();
        }
    }
    
    public Object[] getNext() {
        if (useHashJoin) {
            if (hashResultIterator != null && hashResultIterator.hasNext()) {
                return hashResultIterator.next();
            }
            return null;
        } else {
            if (streamedIndex < streamedResults.size()) {
                return streamedResults.get(streamedIndex++);
            }
            return null;
        }
    }
    
    private int streamedIndex = 0;
    private boolean isJoined = false;
    
    public List<Object[]> getJoinedRows() {
        return useHashJoin ? null : streamedResults;
    }
    
    public Iterator<Object[]> getRowIterator() {
        if (useHashJoin) {
            return hashResultIterator;
        } else {
            return streamedResults.iterator();
        }
    }
    
    public DBFReader getLeftReader() {
        return leftReader;
    }
    
    public DBFReader getRightReader() {
        return rightReader;
    }
    
    public void reset() {
        streamedIndex = 0;
        if (hashResultIterator != null && streamedResults != null) {
            streamedResults.clear();
        }
        if (hashTable != null) {
            hashTable.clear();
            hashTable = null;
        }
        leftExhausted = false;
        isJoined = false;
    }
    
    public void close() throws IOException {
        if (hashTable != null) {
            hashTable.clear();
            hashTable = null;
        }
        if (streamedResults != null) {
            streamedResults.clear();
        }
        if (rightRowsCache != null) {
            rightRowsCache.clear();
        }
    }
}