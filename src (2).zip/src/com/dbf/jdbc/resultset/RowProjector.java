package com.dbf.jdbc.resultset;

import com.dbf.jdbc.dbf.DBFField;
import com.dbf.jdbc.parser.ast.ColumnNode;
import com.dbf.jdbc.parser.ast.SelectNode;
import java.sql.SQLException;
import java.util.*;

/**
 * Handles column selection and projection from DBF records
 */
public class RowProjector {
    private final List<DBFField> allFields;
    private final List<Integer> selectedColumnIndexes;
    private final List<String> columnNames;
    private final List<String> columnLabels;
    private final Map<String, Integer> columnNameToIndex;
    
    public RowProjector(List<DBFField> fields, SelectNode selectNode) throws SQLException {
        this.allFields = fields;
        this.selectedColumnIndexes = new ArrayList<>();
        this.columnNames = new ArrayList<>();
        this.columnLabels = new ArrayList<>();
        this.columnNameToIndex = new HashMap<>();
        
        if (selectNode == null) {
            // Default: select all columns
            for (int i = 0; i < fields.size(); i++) {
                selectedColumnIndexes.add(i);
                columnNames.add(fields.get(i).getName());
                columnLabels.add(fields.get(i).getName());
                columnNameToIndex.put(fields.get(i).getName().toLowerCase(), i);
            }
        } else if (selectNode.getColumns().size() == 1 && selectNode.getColumns().get(0).isStar()) {
            // SELECT *
            for (int i = 0; i < fields.size(); i++) {
                selectedColumnIndexes.add(i);
                columnNames.add(fields.get(i).getName());
                columnLabels.add(fields.get(i).getName());
                columnNameToIndex.put(fields.get(i).getName().toLowerCase(), i);
            }
        } else {
            // SELECT specific columns
            for (ColumnNode col : selectNode.getColumns()) {
                String colName = col.getColumnName();
                int idx = findColumnIndex(colName);
                if (idx == -1) {
                    throw new SQLException("Column not found: " + colName);
                }
                selectedColumnIndexes.add(idx);
                columnNames.add(fields.get(idx).getName());
                String label = col.getAlias() != null ? col.getAlias() : fields.get(idx).getName();
                columnLabels.add(label);
                columnNameToIndex.put(label.toLowerCase(), selectedColumnIndexes.size() - 1);
            }
        }
    }
    
    private int findColumnIndex(String columnName) {
        for (int i = 0; i < allFields.size(); i++) {
            if (allFields.get(i).getName().equalsIgnoreCase(columnName)) {
                return i;
            }
        }
        return -1;
    }
    
    public Object[] projectRow(Object[] fullRow) {
        Object[] projected = new Object[selectedColumnIndexes.size()];
        for (int i = 0; i < selectedColumnIndexes.size(); i++) {
            int idx = selectedColumnIndexes.get(i);
            projected[i] = (idx < fullRow.length) ? fullRow[idx] : null;
        }
        return projected;
    }
    
    public int getColumnCount() {
        return selectedColumnIndexes.size();
    }
    
    public List<String> getColumnNames() {
        return Collections.unmodifiableList(columnNames);
    }
    
    public List<String> getColumnLabels() {
        return Collections.unmodifiableList(columnLabels);
    }
    
    public int getColumnIndex(String columnLabel) {
        Integer idx = columnNameToIndex.get(columnLabel.toLowerCase());
        return idx != null ? idx : -1;
    }
    
    public String getColumnLabel(int columnIndex) {
        if (columnIndex < 1 || columnIndex > columnLabels.size()) {
            return null;
        }
        return columnLabels.get(columnIndex - 1);
    }
    
    public String getColumnName(int columnIndex) {
        if (columnIndex < 1 || columnIndex > columnNames.size()) {
            return null;
        }
        return columnNames.get(columnIndex - 1);
    }
    
    public List<Integer> getSelectedColumnIndexes() {
        return Collections.unmodifiableList(selectedColumnIndexes);
    }
}