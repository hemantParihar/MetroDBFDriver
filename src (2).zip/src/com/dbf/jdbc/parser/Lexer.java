package com.dbf.jdbc.parser;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Hand-written lexer for SQL (no regex for performance)
 */
public class Lexer {
    private final Reader reader;
    private int currentChar;
    private int line = 1;
    private int column = 0;
    private int position = 0;
    private final List<Token> tokens = new ArrayList<>();
    private int tokenIndex = 0;
    
    private static final Map<String, TokenType> keywords = new HashMap<>();
    
    static {
        // Keywords
        keywords.put("select", TokenType.SELECT);
        keywords.put("from", TokenType.FROM);
        keywords.put("where", TokenType.WHERE);
        keywords.put("and", TokenType.AND);
        keywords.put("or", TokenType.OR);
        keywords.put("not", TokenType.NOT);
        keywords.put("order", TokenType.ORDER);
        keywords.put("by", TokenType.BY);
        keywords.put("asc", TokenType.ASC);
        keywords.put("desc", TokenType.DESC);
        keywords.put("insert", TokenType.INSERT);
        keywords.put("into", TokenType.INTO);
        keywords.put("values", TokenType.VALUES);
        keywords.put("update", TokenType.UPDATE);
        keywords.put("set", TokenType.SET);
        keywords.put("delete", TokenType.DELETE);
        keywords.put("like", TokenType.LIKE);
        keywords.put("in", TokenType.IN);
        keywords.put("between", TokenType.BETWEEN);
        keywords.put("is", TokenType.IS);
        keywords.put("null", TokenType.NULL);
        keywords.put("create", TokenType.CREATE);
        keywords.put("drop", TokenType.DROP);
        keywords.put("table", TokenType.TABLE);
    }
    
    public Lexer(Reader reader) throws IOException {
        this.reader = reader;
        advance();
        tokenize();
    }
    
    private void advance() throws IOException {
        currentChar = reader.read();
        if (currentChar != -1) {
            column++;
            position++;
        }
    }
    
    private void skipWhitespace() throws IOException {
        while (currentChar != -1 && Character.isWhitespace(currentChar)) {
            if (currentChar == '\n') {
                line++;
                column = 0;
            }
            advance();
        }
    }
    
    private void tokenize() throws IOException {
        while (currentChar != -1) {
            skipWhitespace();
            if (currentChar == -1) break;
            
            // Identifiers and keywords
            if (Character.isLetter(currentChar) || currentChar == '_') {
                readIdentifierOrKeyword();
            }
            // Numbers
            else if (Character.isDigit(currentChar) || currentChar == '-') {
                readNumber();
            }
            // String literals
            else if (currentChar == '\'' || currentChar == '"') {
                readString();
            }
            // Single character tokens
            else {
                readSingleCharToken();
            }
        }
        tokens.add(new Token(TokenType.EOF, null, line, column));
    }
    
    private void readIdentifierOrKeyword() throws IOException {
        int startLine = line;
        int startCol = column;
        StringBuilder sb = new StringBuilder();
        
        while (currentChar != -1 && (Character.isLetterOrDigit(currentChar) || currentChar == '_')) {
            sb.append((char) currentChar);
            advance();
        }
        
        String value = sb.toString();
        String lower = value.toLowerCase();
        
        TokenType type = keywords.getOrDefault(lower, TokenType.IDENTIFIER);
        tokens.add(new Token(type, value, startLine, startCol));
    }
    
    private void readNumber() throws IOException {
        int startLine = line;
        int startCol = column;
        StringBuilder sb = new StringBuilder();
        boolean hasDecimal = false;
        
        if (currentChar == '-') {
            sb.append((char) currentChar);
            advance();
        }
        
        while (currentChar != -1 && (Character.isDigit(currentChar) || currentChar == '.')) {
            if (currentChar == '.') {
                if (hasDecimal) break;
                hasDecimal = true;
            }
            sb.append((char) currentChar);
            advance();
        }
        
        tokens.add(new Token(TokenType.NUMBER, sb.toString(), startLine, startCol));
    }
    
    private void readString() throws IOException {
        int startLine = line;
        int startCol = column;
        char quote = (char) currentChar;
        StringBuilder sb = new StringBuilder();
        advance();
        
        while (currentChar != -1 && currentChar != quote) {
            if (currentChar == '\\') {
                advance();
                if (currentChar == 'n') sb.append('\n');
                else if (currentChar == 't') sb.append('\t');
                else if (currentChar == 'r') sb.append('\r');
                else sb.append((char) currentChar);
            } else {
                sb.append((char) currentChar);
            }
            advance();
        }
        
        if (currentChar == quote) {
            advance();
        }
        
        tokens.add(new Token(TokenType.STRING, sb.toString(), startLine, startCol));
    }
    
    private void readSingleCharToken() throws IOException {
        int startLine = line;
        int startCol = column;
        char c = (char) currentChar;
        TokenType type;
        
        switch (c) {
            case '*': type = TokenType.STAR; advance(); break;
            case ',': type = TokenType.COMMA; advance(); break;
            case '.': type = TokenType.DOT; advance(); break;
            case '(': type = TokenType.LPAREN; advance(); break;
            case ')': type = TokenType.RPAREN; advance(); break;
            case '=': type = TokenType.EQ; advance(); break;
            case '<':
                advance();
                if (currentChar == '=') {
                    type = TokenType.LE;
                    advance();
                } else if (currentChar == '>') {
                    type = TokenType.NE;
                    advance();
                } else {
                    type = TokenType.LT;
                }
                break;
            case '>':
                advance();
                if (currentChar == '=') {
                    type = TokenType.GE;
                    advance();
                } else {
                    type = TokenType.GT;
                }
                break;
            default:
                type = TokenType.UNKNOWN;
                advance();
                break;
        }
        
        tokens.add(new Token(type, String.valueOf(c), startLine, startCol));
    }
    
    public Token nextToken() {
        if (tokenIndex >= tokens.size()) {
            return new Token(TokenType.EOF, null, line, column);
        }
        return tokens.get(tokenIndex++);
    }
    
    public void reset() {
        tokenIndex = 0;
    }
    
    public List<Token> getAllTokens() {
        return new ArrayList<>(tokens);
    }
}