package com.dbf.jdbc;

import com.dbf.jdbc.dbf.DBFField;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

public class DBFResultSetMetaData implements ResultSetMetaData {
    private final DBFResultSet resultSet;
    private final List<DBFField> fields;
    private final List<Integer> selectedColumns;
    private final List<String> columnLabels;
    
    public DBFResultSetMetaData(DBFResultSet resultSet, List<DBFField> fields, 
                                 List<Integer> selectedColumns, List<String> columnLabels) {
        this.resultSet = resultSet;
        this.fields = fields;
        this.selectedColumns = selectedColumns;
        this.columnLabels = columnLabels;
    }
    
    private DBFField getField(int column) throws SQLException {
        if (fields == null || column < 1 || column > selectedColumns.size()) {
            throw new SQLException("Invalid column index: " + column);
        }
        int fieldIndex = selectedColumns.get(column - 1);
        return fields.get(fieldIndex);
    }
    
    @Override
    public int getColumnCount() throws SQLException {
        return selectedColumns != null ? selectedColumns.size() : 0;
    }
    
    @Override
    public boolean isAutoIncrement(int column) throws SQLException {
        return false;
    }
    
    @Override
    public boolean isCaseSensitive(int column) throws SQLException {
        return getField(column).getType() == 'C';
    }
    
    @Override
    public boolean isSearchable(int column) throws SQLException {
        return true;
    }
    
    @Override
    public boolean isCurrency(int column) throws SQLException {
        return false;
    }
    
    @Override
    public int isNullable(int column) throws SQLException {
        return columnNullableUnknown;
    }
    
    @Override
    public boolean isSigned(int column) throws SQLException {
        char type = getField(column).getType();
        return type == 'N' || type == 'F' || type == 'I' || type == 'O';
    }
    
    @Override
    public int getColumnDisplaySize(int column) throws SQLException {
        return getField(column).getLength();
    }
    
    @Override
    public String getColumnLabel(int column) throws SQLException {
        if (columnLabels != null && column <= columnLabels.size()) {
            return columnLabels.get(column - 1);
        }
        return getColumnName(column);
    }
    
    @Override
    public String getColumnName(int column) throws SQLException {
        return getField(column).getName();
    }
    
    @Override
    public String getSchemaName(int column) throws SQLException {
        return "";
    }
    
    @Override
    public int getPrecision(int column) throws SQLException {
        return getField(column).getLength();
    }
    
    @Override
    public int getScale(int column) throws SQLException {
        return getField(column).getDecimalCount();
    }
    
    @Override
    public String getTableName(int column) throws SQLException {
        return "";
    }
    
    @Override
    public String getCatalogName(int column) throws SQLException {
        return "";
    }
    
    @Override
    public int getColumnType(int column) throws SQLException {
        return mapTypeToSQL(getField(column).getType());
    }
    
    @Override
    public String getColumnTypeName(int column) throws SQLException {
        return getField(column).getType() + "";
    }
    
    @Override
    public boolean isReadOnly(int column) throws SQLException {
        return true;
    }
    
    @Override
    public boolean isWritable(int column) throws SQLException {
        return false;
    }
    
    @Override
    public boolean isDefinitelyWritable(int column) throws SQLException {
        return false;
    }
    
    @Override
    public String getColumnClassName(int column) throws SQLException {
        return mapTypeToClass(getField(column).getType());
    }
    
    private int mapTypeToSQL(char dbfType) {
        switch (dbfType) {
            case 'C': return Types.VARCHAR;
            case 'N':
            case 'F':
                return Types.DOUBLE;
            case 'D': return Types.DATE;
            case 'L': return Types.BOOLEAN;
            case 'I': return Types.INTEGER;
            case 'O': return Types.DOUBLE;
            case 'M': return Types.CLOB;
            default: return Types.VARCHAR;
        }
    }
    
    private String mapTypeToClass(char dbfType) {
        switch (dbfType) {
            case 'C': return String.class.getName();
            case 'N':
            case 'F':
            case 'O': return Double.class.getName();
            case 'D': return java.sql.Date.class.getName();
            case 'L': return Boolean.class.getName();
            case 'I': return Integer.class.getName();
            case 'M': return String.class.getName();
            default: return String.class.getName();
        }
    }
    
    @Override
    public <T> T unwrap(Class<T> iface) throws SQLException {
        if (iface.isInstance(this)) {
            return iface.cast(this);
        }
        throw new SQLException("Cannot unwrap to " + iface);
    }
    
    @Override
    public boolean isWrapperFor(Class<?> iface) throws SQLException {
        return iface.isInstance(this);
    }
}