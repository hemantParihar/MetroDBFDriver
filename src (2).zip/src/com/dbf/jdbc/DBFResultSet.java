package com.dbf.jdbc;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import com.dbf.jdbc.dbf.DBFReader;
import com.dbf.jdbc.execution.Operator;
import com.dbf.jdbc.execution.ProjectionOperator;
import com.dbf.jdbc.parser.ast.SelectNode;
import com.dbf.jdbc.resultset.AggregateEngine;
import com.dbf.jdbc.resultset.FilterEngine;
import com.dbf.jdbc.resultset.JoinEngine;
import com.dbf.jdbc.resultset.ResultSetCursor;
import com.dbf.jdbc.resultset.RowNavigator;
import com.dbf.jdbc.resultset.RowProjector;
import com.dbf.jdbc.resultset.SortEngine;
import com.dbf.jdbc.resultset.TypeConverter;

/**
 * JDBC ResultSet implementation for DBF
 * Orchestrates all the specialized engines
 */
public class DBFResultSet implements ResultSet {
    private DBFReader reader;
    private RowProjector projector;
    private FilterEngine filter;
    private SortEngine sorter;
    private AggregateEngine aggregator;
    private JoinEngine joiner;
    private ResultSetCursor cursor;
    private RowNavigator navigator;
    
    private boolean wasNull = false;
    private boolean closed = false;
    private SQLWarning warnings = null;
    private int type = TYPE_FORWARD_ONLY;
    private int concurrency = CONCUR_READ_ONLY;
    
    // Cached processed rows
    private List<Object[]> processedRows;
    private List<Map<String, Object>> aggregatedRows;
    private Operator rootOperator;
    private Object[] currentRow = null;
    
    // Constructor for Operator-based execution (NEW)
    public DBFResultSet(Operator rootOperator, SelectNode selectNode) throws SQLException {
        this.rootOperator = rootOperator;
        this.cursor = new ResultSetCursor();
        this.navigator = new RowNavigator(cursor);
        
        // Build projector from operator
        if (rootOperator instanceof ProjectionOperator) {
            this.projector = buildProjectorFromOperator((ProjectionOperator) rootOperator);
        } else {
            this.projector = null;
        }
        
        this.filter = null;
        this.sorter = null;
        this.aggregator = null;
        this.joiner = null;
        this.reader = null;
        
        // Load rows from operator
        loadRowsFromOperator();
    }
    
    private RowProjector buildProjectorFromOperator(ProjectionOperator proj) {
        // Build projector from projection operator
        // In production, you'd extract column info from the operator
        // For now, create a simple projector with the column info
        try {
            List<com.dbf.jdbc.dbf.DBFField> dummyFields = new ArrayList<>();
            for (int i = 0; i < proj.getColumnCount(); i++) {
                com.dbf.jdbc.dbf.DBFField field = new com.dbf.jdbc.dbf.DBFField();
                field.setName(proj.getColumnLabel(i + 1));
                field.setType('C');
                field.setLength(255);
                dummyFields.add(field);
            }
            return new RowProjector(dummyFields, null);
        } catch (SQLException e) {
            return null;
        }
    }
    
    private void loadRowsFromOperator() throws SQLException {
        List<Object[]> rows = new ArrayList<>();
        Object[] row;
        try {
            while ((row = rootOperator.next()) != null) {
                rows.add(row);
            }
        } catch (IOException e) {
            throw new SQLException("Error loading rows: " + e.getMessage(), e);
        }
        cursor.setRows(rows);
        processedRows = rows;
    }
    
    // Constructor for traditional reader-based execution
    public DBFResultSet(DBFReader reader, SelectNode selectNode) throws SQLException {
        this.reader = reader;
        this.projector = new RowProjector(reader.getHeader().getFields(), selectNode);
        this.filter = new FilterEngine(
            selectNode != null && selectNode.getWhere() != null ? 
            selectNode.getWhere().getCondition() : null, 
            projector);
        this.sorter = new SortEngine(
            selectNode != null ? selectNode.getOrderBy() : null, 
            projector);
        this.aggregator = new AggregateEngine(selectNode, projector);
        this.cursor = new ResultSetCursor();
        this.navigator = new RowNavigator(cursor);
        this.rootOperator = null;
        
        // Initialize joiner if needed
        if (selectNode != null && selectNode.getJoin() != null) {
            this.joiner = null;
        } else {
            this.joiner = null;
        }
        
        // Load and process rows
        loadRowsFromReader();
    }
    
    // Constructor for joined result sets
    public DBFResultSet(DBFReader reader, JoinEngine joiner, RowProjector projector) throws SQLException {
        this.reader = reader;
        this.joiner = joiner;
        this.projector = projector;
        this.filter = null;
        this.sorter = null;
        this.aggregator = null;
        this.cursor = new ResultSetCursor();
        this.navigator = new RowNavigator(cursor);
        this.rootOperator = null;
        
        loadJoinedRows();
    }
    
    private void loadRowsFromReader() throws SQLException {
        try {
            List<Object[]> allRows = new ArrayList<>();
            reader.beforeFirst();
            
            while (reader.next()) {
                // Get full row
                Object[] fullRow = new Object[reader.getHeader().getFieldCount()];
                for (int i = 0; i < fullRow.length; i++) {
                    fullRow[i] = reader.getValue(i);
                }
                
                // Apply filter
                if (filter == null || filter.matches(fullRow)) {
                    // Project columns
                    Object[] projectedRow = projector.projectRow(fullRow);
                    allRows.add(projectedRow);
                }
            }
            
            // Apply aggregation if needed
            if (aggregator != null && aggregator.hasAggregation()) {
                aggregatedRows = aggregator.aggregate(allRows, projector);
                cursor.setAggregatedRows(aggregatedRows);
            } else {
                // Apply sorting
                if (sorter != null && sorter.hasSort()) {
                    allRows = sorter.sort(allRows);
                }
                processedRows = allRows;
                cursor.setRows(processedRows);
            }
            
        } catch (IOException e) {
            throw new SQLException("Error loading rows: " + e.getMessage(), e);
        }
    }
    
    private void loadJoinedRows() throws SQLException {
        if (joiner == null || !joiner.isJoined()) {
            return;
        }
        
        List<Object[]> joinedRows = joiner.getJoinedRows();
        List<Object[]> projectedRows = new ArrayList<>();
        
        for (Object[] fullRow : joinedRows) {
            Object[] projectedRow = projector.projectRow(fullRow);
            projectedRows.add(projectedRow);
        }
        
        processedRows = projectedRows;
        cursor.setRows(processedRows);
    }
    
    private Object getCurrentValue(int columnIndex) throws SQLException {
        checkClosed();
        
        if (cursor.isAggregated()) {
            Map<String, Object> row = cursor.getCurrentAggregatedRow();
            if (row == null) {
                throw new SQLException("No current row");
            }
            String colName = projector.getColumnLabel(columnIndex);
            Object value = row.get(colName);
            wasNull = (value == null);
            return value;
        }
        
        Object[] row = cursor.getCurrentRow();
        if (row == null) {
            throw new SQLException("No current row");
        }
        
        int colIdx = columnIndex - 1;
        if (colIdx < 0 || colIdx >= row.length) {
            throw new SQLException("Invalid column index: " + columnIndex);
        }
        
        Object value = row[colIdx];
        wasNull = (value == null);
        return value;
    }
    
    private void checkClosed() throws SQLException {
        if (closed) {
            throw new SQLException("ResultSet is closed");
        }
    }
    
    // ==================== ResultSet Interface Implementation ====================
    
    @Override
    public boolean next() throws SQLException {
        checkClosed();
        boolean hasNext = navigator.next();
        if (hasNext) {
            if (rootOperator != null) {
                // For operator-based execution
                try {
                    currentRow = rootOperator.next();
                } catch (IOException e) {
                    throw new SQLException("Error getting next row: " + e.getMessage(), e);
                }
            } else {
                currentRow = cursor.getCurrentRow();
            }
        }
        return hasNext;
    }
    
    @Override
    public void close() throws SQLException {
        if (!closed) {
            closed = true;
            if (rootOperator != null) {
                try {
                    rootOperator.close();
                } catch (IOException e) {
                    throw new SQLException("Error closing operator: " + e.getMessage(), e);
                }
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    throw new SQLException("Error closing DBF reader: " + e.getMessage(), e);
                }
            }
        }
    }
    
    @Override
    public boolean wasNull() throws SQLException {
        return wasNull;
    }
    
    @Override
    public String getString(int columnIndex) throws SQLException {
        return TypeConverter.toString(getCurrentValue(columnIndex));
    }
    
    @Override
    public boolean getBoolean(int columnIndex) throws SQLException {
        return TypeConverter.toBoolean(getCurrentValue(columnIndex));
    }
    
    @Override
    public byte getByte(int columnIndex) throws SQLException {
        return TypeConverter.toByte(getCurrentValue(columnIndex));
    }
    
    @Override
    public short getShort(int columnIndex) throws SQLException {
        return TypeConverter.toShort(getCurrentValue(columnIndex));
    }
    
    @Override
    public int getInt(int columnIndex) throws SQLException {
        return TypeConverter.toInt(getCurrentValue(columnIndex));
    }
    
    @Override
    public long getLong(int columnIndex) throws SQLException {
        return TypeConverter.toLong(getCurrentValue(columnIndex));
    }
    
    @Override
    public float getFloat(int columnIndex) throws SQLException {
        return TypeConverter.toFloat(getCurrentValue(columnIndex));
    }
    
    @Override
    public double getDouble(int columnIndex) throws SQLException {
        return TypeConverter.toDouble(getCurrentValue(columnIndex));
    }
    
    @Override
    public BigDecimal getBigDecimal(int columnIndex) throws SQLException {
        Number n = TypeConverter.toNumber(getCurrentValue(columnIndex));
        return n != null ? BigDecimal.valueOf(n.doubleValue()) : null;
    }
    
    @Override
    public BigDecimal getBigDecimal(int columnIndex, int scale) throws SQLException {
        return TypeConverter.toBigDecimal(getCurrentValue(columnIndex), scale);
    }
    
    @Override
    public byte[] getBytes(int columnIndex) throws SQLException {
        return TypeConverter.toBytes(getCurrentValue(columnIndex));
    }
    
    @Override
    public Date getDate(int columnIndex) throws SQLException {
        return TypeConverter.toDate(getCurrentValue(columnIndex));
    }
    
    @Override
    public Time getTime(int columnIndex) throws SQLException {
        return TypeConverter.toTime(getCurrentValue(columnIndex));
    }
    
    @Override
    public Timestamp getTimestamp(int columnIndex) throws SQLException {
        return TypeConverter.toTimestamp(getCurrentValue(columnIndex));
    }
    
    @Override
    public InputStream getAsciiStream(int columnIndex) throws SQLException {
        String s = getString(columnIndex);
        return s != null ? new java.io.ByteArrayInputStream(s.getBytes()) : null;
    }
    
    @Override
    public InputStream getUnicodeStream(int columnIndex) throws SQLException {
        return getAsciiStream(columnIndex);
    }
    
    @Override
    public InputStream getBinaryStream(int columnIndex) throws SQLException {
        byte[] bytes = getBytes(columnIndex);
        return bytes != null ? new java.io.ByteArrayInputStream(bytes) : null;
    }
    
    @Override
    public String getString(String columnLabel) throws SQLException {
        return getString(findColumn(columnLabel));
    }
    
    @Override
    public boolean getBoolean(String columnLabel) throws SQLException {
        return getBoolean(findColumn(columnLabel));
    }
    
    @Override
    public byte getByte(String columnLabel) throws SQLException {
        return getByte(findColumn(columnLabel));
    }
    
    @Override
    public short getShort(String columnLabel) throws SQLException {
        return getShort(findColumn(columnLabel));
    }
    
    @Override
    public int getInt(String columnLabel) throws SQLException {
        return getInt(findColumn(columnLabel));
    }
    
    @Override
    public long getLong(String columnLabel) throws SQLException {
        return getLong(findColumn(columnLabel));
    }
    
    @Override
    public float getFloat(String columnLabel) throws SQLException {
        return getFloat(findColumn(columnLabel));
    }
    
    @Override
    public double getDouble(String columnLabel) throws SQLException {
        return getDouble(findColumn(columnLabel));
    }
    
    @Override
    public BigDecimal getBigDecimal(String columnLabel) throws SQLException {
        return getBigDecimal(findColumn(columnLabel));
    }
    
    @Override
    public BigDecimal getBigDecimal(String columnLabel, int scale) throws SQLException {
        return getBigDecimal(findColumn(columnLabel), scale);
    }
    
    @Override
    public byte[] getBytes(String columnLabel) throws SQLException {
        return getBytes(findColumn(columnLabel));
    }
    
    @Override
    public Date getDate(String columnLabel) throws SQLException {
        return getDate(findColumn(columnLabel));
    }
    
    @Override
    public Time getTime(String columnLabel) throws SQLException {
        return getTime(findColumn(columnLabel));
    }
    
    @Override
    public Timestamp getTimestamp(String columnLabel) throws SQLException {
        return getTimestamp(findColumn(columnLabel));
    }
    
    @Override
    public InputStream getAsciiStream(String columnLabel) throws SQLException {
        return getAsciiStream(findColumn(columnLabel));
    }
    
    @Override
    public InputStream getUnicodeStream(String columnLabel) throws SQLException {
        return getUnicodeStream(findColumn(columnLabel));
    }
    
    @Override
    public InputStream getBinaryStream(String columnLabel) throws SQLException {
        return getBinaryStream(findColumn(columnLabel));
    }
    
    @Override
    public SQLWarning getWarnings() throws SQLException {
        return warnings;
    }
    
    @Override
    public void clearWarnings() throws SQLException {
        warnings = null;
    }
    
    @Override
    public String getCursorName() throws SQLException {
        throw new SQLFeatureNotSupportedException("getCursorName not supported");
    }
    
    @Override
    public ResultSetMetaData getMetaData() throws SQLException {
        if (projector != null && reader != null) {
            return new DBFResultSetMetaData(this, reader.getHeader().getFields(), 
                projector.getSelectedColumnIndexes(), projector.getColumnLabels());
        } else if (projector != null) {
            // For operator-based execution
            List<com.dbf.jdbc.dbf.DBFField> dummyFields = new ArrayList<>();
            for (int i = 0; i < projector.getColumnCount(); i++) {
                com.dbf.jdbc.dbf.DBFField field = new com.dbf.jdbc.dbf.DBFField();
                field.setName(projector.getColumnLabel(i + 1));
                field.setType('C');
                dummyFields.add(field);
            }
            List<Integer> allIndexes = new ArrayList<>();
            for (int i = 0; i < projector.getColumnCount(); i++) {
                allIndexes.add(i);
            }
            return new DBFResultSetMetaData(this, dummyFields, allIndexes, projector.getColumnLabels());
        }
        throw new SQLException("ResultSetMetaData not available");
    }
    
    @Override
    public Object getObject(int columnIndex) throws SQLException {
        return getCurrentValue(columnIndex);
    }
    
    @Override
    public Object getObject(String columnLabel) throws SQLException {
        return getObject(findColumn(columnLabel));
    }
    
    @Override
    public int findColumn(String columnLabel) throws SQLException {
        if (projector == null) {
            throw new SQLException("No column information available");
        }
        int idx = projector.getColumnIndex(columnLabel);
        if (idx == -1) {
            throw new SQLException("Column not found: " + columnLabel);
        }
        return idx + 1;
    }
    
    // Navigation methods delegate to navigator
    @Override
    public boolean isBeforeFirst() throws SQLException { 
        checkClosed();
        return navigator.isBeforeFirst(); 
    }
    
    @Override
    public boolean isAfterLast() throws SQLException { 
        checkClosed();
        return navigator.isAfterLast(); 
    }
    
    @Override
    public boolean isFirst() throws SQLException { 
        checkClosed();
        return navigator.isFirst(); 
    }
    
    @Override
    public boolean isLast() throws SQLException { 
        checkClosed();
        return navigator.isLast(); 
    }
    
    @Override
    public void beforeFirst() throws SQLException { 
        checkClosed();
        navigator.beforeFirst(); 
    }
    
    @Override
    public void afterLast() throws SQLException { 
        checkClosed();
        navigator.afterLast(); 
    }
    
    @Override
    public boolean first() throws SQLException { 
        checkClosed();
        return navigator.first(); 
    }
    
    @Override
    public boolean last() throws SQLException { 
        checkClosed();
        return navigator.last(); 
    }
    
    @Override
    public int getRow() throws SQLException { 
        checkClosed();
        return navigator.getRow(); 
    }
    
    @Override
    public boolean absolute(int row) throws SQLException { 
        checkClosed();
        return navigator.absolute(row); 
    }
    
    @Override
    public boolean relative(int rows) throws SQLException { 
        checkClosed();
        return navigator.relative(rows); 
    }
    
    @Override
    public boolean previous() throws SQLException { 
        checkClosed();
        return navigator.previous(); 
    }
    
//    @Override
//    public void setFetchDirection(int direction) throws SQLException { 
//        checkClosed();
//        navigator.setFetchDirection(direction); 
//    }
//    
//    @Override
//    public int getFetchDirection() throws SQLException { 
//        checkClosed();
//        return navigator.getFetchDirection(); 
//    }
//    
//    @Override
//    public void setFetchSize(int rows) throws SQLException { 
//        checkClosed();
//        navigator.setFetchSize(rows); 
//    }
//    
//    @Override
//    public int getFetchSize() throws SQLException { 
//        checkClosed();
//        return navigator.getFetchSize(); 
//    }
    
    @Override
    public int getType() throws SQLException { 
        return type; 
    }
    
    @Override
    public int getConcurrency() throws SQLException { 
        return concurrency; 
    }
    
    @Override
    public boolean rowUpdated() throws SQLException { 
        return false; 
    }
    
    @Override
    public boolean rowInserted() throws SQLException { 
        return false; 
    }
    
    @Override
    public boolean rowDeleted() throws SQLException { 
        return false; 
    }
    
    @Override
    public void updateNull(int columnIndex) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateBoolean(int columnIndex, boolean x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateByte(int columnIndex, byte x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateShort(int columnIndex, short x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateInt(int columnIndex, int x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateLong(int columnIndex, long x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateFloat(int columnIndex, float x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateDouble(int columnIndex, double x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateBigDecimal(int columnIndex, BigDecimal x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateString(int columnIndex, String x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateBytes(int columnIndex, byte[] x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateDate(int columnIndex, Date x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateTime(int columnIndex, Time x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateTimestamp(int columnIndex, Timestamp x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateAsciiStream(int columnIndex, InputStream x, int length) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateBinaryStream(int columnIndex, InputStream x, int length) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateCharacterStream(int columnIndex, Reader x, int length) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateObject(int columnIndex, Object x, int scaleOrLength) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateObject(int columnIndex, Object x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateNull(String columnLabel) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateBoolean(String columnLabel, boolean x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateByte(String columnLabel, byte x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateShort(String columnLabel, short x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateInt(String columnLabel, int x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateLong(String columnLabel, long x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateFloat(String columnLabel, float x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateDouble(String columnLabel, double x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateBigDecimal(String columnLabel, BigDecimal x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateString(String columnLabel, String x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateBytes(String columnLabel, byte[] x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateDate(String columnLabel, Date x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateTime(String columnLabel, Time x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateTimestamp(String columnLabel, Timestamp x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateAsciiStream(String columnLabel, InputStream x, int length) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateBinaryStream(String columnLabel, InputStream x, int length) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateCharacterStream(String columnLabel, Reader reader, int length) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateObject(String columnLabel, Object x, int scaleOrLength) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateObject(String columnLabel, Object x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void insertRow() throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateRow() throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void deleteRow() throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void refreshRow() throws SQLException { 
        // Read-only, nothing to refresh
    }
    
    @Override
    public void cancelRowUpdates() throws SQLException { 
        // Read-only, nothing to cancel
    }
    
    @Override
    public void moveToInsertRow() throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void moveToCurrentRow() throws SQLException { 
        // Read-only, nothing to do
    }
    
    @Override
    public Statement getStatement() throws SQLException { 
        return null; 
    }
    
    @Override
    public Object getObject(int columnIndex, Map<String, Class<?>> map) throws SQLException { 
        return getObject(columnIndex); 
    }
    
    @Override
    public Ref getRef(int columnIndex) throws SQLException { 
        throw new SQLFeatureNotSupportedException("getRef not supported"); 
    }
    
    @Override
    public Blob getBlob(int columnIndex) throws SQLException { 
        byte[] bytes = getBytes(columnIndex);
        return bytes != null ? new DBFBlob(bytes) : null; 
    }
    
    @Override
    public Clob getClob(int columnIndex) throws SQLException { 
        String s = getString(columnIndex);
        return s != null ? new DBFClob(s) : null; 
    }
    
    @Override
    public Array getArray(int columnIndex) throws SQLException { 
        throw new SQLFeatureNotSupportedException("getArray not supported"); 
    }
    
    @Override
    public Object getObject(String columnLabel, Map<String, Class<?>> map) throws SQLException { 
        return getObject(columnLabel); 
    }
    
    @Override
    public Ref getRef(String columnLabel) throws SQLException { 
        return getRef(findColumn(columnLabel)); 
    }
    
    @Override
    public Blob getBlob(String columnLabel) throws SQLException { 
        return getBlob(findColumn(columnLabel)); 
    }
    
    @Override
    public Clob getClob(String columnLabel) throws SQLException { 
        return getClob(findColumn(columnLabel)); 
    }
    
    @Override
    public Array getArray(String columnLabel) throws SQLException { 
        return getArray(findColumn(columnLabel)); 
    }
    
    @Override
    public Date getDate(int columnIndex, Calendar cal) throws SQLException { 
        return getDate(columnIndex); 
    }
    
    @Override
    public Date getDate(String columnLabel, Calendar cal) throws SQLException { 
        return getDate(columnLabel); 
    }
    
    @Override
    public Time getTime(int columnIndex, Calendar cal) throws SQLException { 
        return getTime(columnIndex); 
    }
    
    @Override
    public Time getTime(String columnLabel, Calendar cal) throws SQLException { 
        return getTime(columnLabel); 
    }
    
    @Override
    public Timestamp getTimestamp(int columnIndex, Calendar cal) throws SQLException { 
        return getTimestamp(columnIndex); 
    }
    
    @Override
    public Timestamp getTimestamp(String columnLabel, Calendar cal) throws SQLException { 
        return getTimestamp(columnLabel); 
    }
    
    @Override
    public URL getURL(int columnIndex) throws SQLException { 
        throw new SQLFeatureNotSupportedException("getURL not supported"); 
    }
    
    @Override
    public URL getURL(String columnLabel) throws SQLException { 
        throw new SQLFeatureNotSupportedException("getURL not supported"); 
    }
    
    @Override
    public void updateRef(int columnIndex, Ref x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateRef(String columnLabel, Ref x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateBlob(int columnIndex, Blob x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateBlob(String columnLabel, Blob x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateClob(int columnIndex, Clob x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateClob(String columnLabel, Clob x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateArray(int columnIndex, Array x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateArray(String columnLabel, Array x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public RowId getRowId(int columnIndex) throws SQLException { 
        throw new SQLFeatureNotSupportedException("getRowId not supported"); 
    }
    
    @Override
    public RowId getRowId(String columnLabel) throws SQLException { 
        throw new SQLFeatureNotSupportedException("getRowId not supported"); 
    }
    
    @Override
    public void updateRowId(int columnIndex, RowId x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateRowId(String columnLabel, RowId x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public int getHoldability() throws SQLException { 
        return HOLD_CURSORS_OVER_COMMIT; 
    }
    
    @Override
    public boolean isClosed() throws SQLException { 
        return closed; 
    }
    
    @Override
    public void updateNString(int columnIndex, String nString) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateNString(String columnLabel, String nString) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateNClob(int columnIndex, NClob nClob) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateNClob(String columnLabel, NClob nClob) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public NClob getNClob(int columnIndex) throws SQLException { 
        String s = getString(columnIndex);
        return s != null ? new DBFNClob(s) : null; 
    }
    
    @Override
    public NClob getNClob(String columnLabel) throws SQLException { 
        return getNClob(findColumn(columnLabel)); 
    }
    
    @Override
    public SQLXML getSQLXML(int columnIndex) throws SQLException { 
        throw new SQLFeatureNotSupportedException("getSQLXML not supported"); 
    }
    
    @Override
    public SQLXML getSQLXML(String columnLabel) throws SQLException { 
        throw new SQLFeatureNotSupportedException("getSQLXML not supported"); 
    }
    
    @Override
    public void updateSQLXML(int columnIndex, SQLXML xmlObject) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateSQLXML(String columnLabel, SQLXML xmlObject) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public String getNString(int columnIndex) throws SQLException { 
        return getString(columnIndex); 
    }
    
    @Override
    public String getNString(String columnLabel) throws SQLException { 
        return getString(columnLabel); 
    }
    
    @Override
    public Reader getNCharacterStream(int columnIndex) throws SQLException { 
        String s = getString(columnIndex);
        return s != null ? new java.io.StringReader(s) : null; 
    }
    
    @Override
    public Reader getNCharacterStream(String columnLabel) throws SQLException { 
        return getNCharacterStream(findColumn(columnLabel)); 
    }
    
    @Override
    public void updateNCharacterStream(int columnIndex, Reader x, long length) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateNCharacterStream(String columnLabel, Reader reader, long length) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateAsciiStream(int columnIndex, InputStream x, long length) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateBinaryStream(int columnIndex, InputStream x, long length) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateCharacterStream(int columnIndex, Reader x, long length) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateAsciiStream(String columnLabel, InputStream x, long length) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateBinaryStream(String columnLabel, InputStream x, long length) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateCharacterStream(String columnLabel, Reader reader, long length) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateBlob(int columnIndex, InputStream inputStream, long length) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateBlob(String columnLabel, InputStream inputStream, long length) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateClob(int columnIndex, Reader reader, long length) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateClob(String columnLabel, Reader reader, long length) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateNClob(int columnIndex, Reader reader, long length) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateNClob(String columnLabel, Reader reader, long length) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateNCharacterStream(int columnIndex, Reader x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateNCharacterStream(String columnLabel, Reader reader) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateAsciiStream(int columnIndex, InputStream x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateBinaryStream(int columnIndex, InputStream x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateCharacterStream(int columnIndex, Reader x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateAsciiStream(String columnLabel, InputStream x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateBinaryStream(String columnLabel, InputStream x) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateCharacterStream(String columnLabel, Reader reader) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateBlob(int columnIndex, InputStream inputStream) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateBlob(String columnLabel, InputStream inputStream) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateClob(int columnIndex, Reader reader) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateClob(String columnLabel, Reader reader) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateNClob(int columnIndex, Reader reader) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public void updateNClob(String columnLabel, Reader reader) throws SQLException { 
        throw new SQLFeatureNotSupportedException("Updates not supported"); 
    }
    
    @Override
    public <T> T getObject(int columnIndex, Class<T> type) throws SQLException {
        Object obj = getObject(columnIndex);
        if (type.isInstance(obj)) {
            return type.cast(obj);
        }
        throw new SQLException("Cannot cast " + (obj != null ? obj.getClass() : "null") + " to " + type);
    }
    
    @Override
    public <T> T getObject(String columnLabel, Class<T> type) throws SQLException {
        return getObject(findColumn(columnLabel), type);
    }
    
    @Override
    public <T> T unwrap(Class<T> iface) throws SQLException {
        if (iface.isInstance(this)) {
            return iface.cast(this);
        }
        throw new SQLException("Cannot unwrap to " + iface);
    }
    
    @Override
    public boolean isWrapperFor(Class<?> iface) throws SQLException {
        return iface.isInstance(this);
    }
    
    @Override
    public Reader getCharacterStream(int columnIndex) throws SQLException {
        String s = getString(columnIndex);
        return s != null ? new java.io.StringReader(s) : null;
    }
    
    @Override
    public Reader getCharacterStream(String columnLabel) throws SQLException {
        return getCharacterStream(findColumn(columnLabel));
    }
    
    // Helper methods for testing/debugging
    public RowProjector getProjector() {
        return projector;
    }
    
    public ResultSetCursor getCursor() {
        return cursor;
    }
    
//    public void setFetchSize(int size) {
//        if (cursor != null) {
//            cursor.setFetchSize(size);
//        }
//    }
 // ==================== Fetch Size and Direction Methods ====================

    @Override
    public void setFetchSize(int rows) throws SQLException { 
        checkClosed();
        if (rows < 0) {
            throw new SQLException("Fetch size cannot be negative: " + rows);
        }
        if (cursor != null) {
            cursor.setFetchSize(rows);
        }
        if (navigator != null) {
            navigator.setFetchSize(rows);
        }
    }

    @Override
    public int getFetchSize() throws SQLException { 
        checkClosed();
        return navigator != null ? navigator.getFetchSize() : 0;
    }

    @Override
    public void setFetchDirection(int direction) throws SQLException { 
        checkClosed();
        if (direction != FETCH_FORWARD && direction != FETCH_REVERSE && direction != FETCH_UNKNOWN) {
            throw new SQLException("Invalid fetch direction: " + direction);
        }
        if (navigator != null) {
            navigator.setFetchDirection(direction);
        }
    }

    @Override
    public int getFetchDirection() throws SQLException { 
        checkClosed();
        return navigator != null ? navigator.getFetchDirection() : FETCH_FORWARD;
    }
    // Inner classes for Blob/Clob support
    private static class DBFBlob implements Blob {
        private final byte[] data;
        private boolean closed = false;
        
        DBFBlob(byte[] data) { 
            this.data = data != null ? data : new byte[0]; 
        }
        
        @Override public long length() { return data.length; }
        @Override public byte[] getBytes(long pos, int length) {
            int start = (int) pos - 1;
            int len = Math.min(length, data.length - start);
            byte[] result = new byte[len];
            System.arraycopy(data, start, result, 0, len);
            return result;
        }
        @Override public InputStream getBinaryStream() { return new java.io.ByteArrayInputStream(data); }
        @Override public long position(byte[] pattern, long start) { return -1; }
        @Override public long position(Blob pattern, long start) { return -1; }
        @Override public int setBytes(long pos, byte[] bytes) { throw new UnsupportedOperationException(); }
        @Override public int setBytes(long pos, byte[] bytes, int offset, int len) { throw new UnsupportedOperationException(); }
        @Override public OutputStream setBinaryStream(long pos) { throw new UnsupportedOperationException(); }
        @Override public void truncate(long len) { }
        @Override public void free() { closed = true; }
        @Override public InputStream getBinaryStream(long pos, long length) { return getBinaryStream(); }
    }
    
    private static class DBFClob implements Clob {
        private final String data;
        private boolean closed = false;
        
        DBFClob(String data) { 
            this.data = data != null ? data : ""; 
        }
        
        @Override public long length() { return data.length(); }
        @Override public String getSubString(long pos, int length) {
            return data.substring((int) pos - 1, Math.min((int) pos - 1 + length, data.length()));
        }
        @Override public Reader getCharacterStream() { return new java.io.StringReader(data); }
        @Override public InputStream getAsciiStream() { return new java.io.ByteArrayInputStream(data.getBytes()); }
        @Override public long position(String searchstr, long start) { 
            int idx = data.indexOf(searchstr, (int) start - 1);
            return idx >= 0 ? idx + 1 : -1;
        }
        @Override public long position(Clob searchstr, long start) { 
            try {
				return position(searchstr.getSubString(1, (int) searchstr.length()), start);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return start; 
        }
        @Override public int setString(long pos, String str) { throw new UnsupportedOperationException(); }
        @Override public int setString(long pos, String str, int offset, int len) { throw new UnsupportedOperationException(); }
        @Override public OutputStream setAsciiStream(long pos) { throw new UnsupportedOperationException(); }
        @Override public Writer setCharacterStream(long pos) { throw new UnsupportedOperationException(); }
        @Override public void truncate(long len) { }
        @Override public void free() { closed = true; }
        @Override public Reader getCharacterStream(long pos, long length) { return getCharacterStream(); }
    }
    
    private static class DBFNClob extends DBFClob implements NClob {
        DBFNClob(String data) { super(data); }
    }
}