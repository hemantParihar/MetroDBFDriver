package com.dbf.jdbc.dbf;

import java.io.Closeable;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.Charset;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicBoolean;

import com.dbf.jdbc.DBFConstants;
import com.dbf.jdbc.index.MDXIndex;
import com.dbf.jdbc.index.NDXIndex;
import com.dbf.jdbc.memo.MemoFile;

public class DBFReader implements Closeable {
    private final RandomAccessFile file;
    private final DBFHeader header;
    private final Charset charset;
    private final PageCache pageCache;
    private final AtomicBoolean closed = new AtomicBoolean(false);
    private byte[] recordBuffer;
    private int currentRecord = -1;
    private boolean currentRecordDeleted = false;
    
    // New fields for enhanced features
    private MemoFile memoFile;
    private NDXIndex ndxIndex;
    private MDXIndex mdxIndex;
    private String currentIndexTag;
    
    // Join support
    private DBFReader joinedReader;
    private JoinType joinType;
    private String joinLeftColumn;
    private String joinRightColumn;
    private List<Object[]> joinedRows;
    private int joinedRowIndex = -1;
    private boolean isJoined = false;
    
    // Aggregation support
    private boolean isAggregated = false;
    private List<Map<String, Object>> aggregatedRows;
    private int aggregatedRowIndex = -1;
    
    // Group by support
    private List<String> groupByColumns;
    private Map<GroupKey, List<Object[]>> groupedRows;
    
    private static final int PAGE_SIZE = 8192;
    private static final int MAX_PAGES = 128;
    
    public DBFReader(String filePath, Charset charset) throws IOException {
        this.file = new RandomAccessFile(filePath, "r");
        this.charset = charset;
        this.pageCache = new PageCache(PAGE_SIZE, MAX_PAGES);
        
        this.header = new DBFHeader();
        this.header.read(this.file, charset);
        this.recordBuffer = new byte[header.getRecordSize()];
        
     // Initialize memo support if needed
        if (header.hasMemo()) {
            try {
                this.memoFile = new MemoFile(filePath, charset);
            } catch (IOException e) {
                // Memo file doesn't exist or can't be read - continue without memo support
                System.err.println("Warning: Could not load memo file: " + e.getMessage());
                this.memoFile = null;
            }
        }
    }
    
    // Index methods
    public void loadNDXIndex(String indexPath) throws IOException {
        this.ndxIndex = new NDXIndex(indexPath);
        this.ndxIndex.load();
    }
    
    public void loadMDXIndex(String indexPath) throws IOException {
        this.mdxIndex = new MDXIndex(indexPath);
    }
    
    public void setCurrentIndexTag(String tagName) {
        this.currentIndexTag = tagName;
    }
    
    public int findRecordByIndex(String key) {
        if (ndxIndex != null) {
            return ndxIndex.findRecord(key);
        }
        if (mdxIndex != null && currentIndexTag != null) {
            return mdxIndex.findRecord(currentIndexTag, key);
        }
        return -1;
    }
    
    public boolean goToRecordByIndex(String key) throws IOException {
        int recordNum = findRecordByIndex(key);
        if (recordNum > 0) {
            absolute(recordNum);
            return true;
        }
        return false;
    }
    
    // Join methods
    public void performJoin(DBFReader rightReader, JoinType type, String leftColumn, String rightColumn) throws IOException {
        this.joinedReader = rightReader;
        this.joinType = type;
        this.joinLeftColumn = leftColumn;
        this.joinRightColumn = rightColumn;
        this.isJoined = true;
        this.joinedRows = new ArrayList<>();
        
        // Load all rows from both tables
        List<Object[]> leftRows = new ArrayList<>();
        beforeFirst();
        while (next()) {
            leftRows.add(getCurrentRowArray());
        }
        
        List<Object[]> rightRows = new ArrayList<>();
        rightReader.beforeFirst();
        while (rightReader.next()) {
            Object[] row = new Object[rightReader.getHeader().getFieldCount()];
            for (int i = 0; i < row.length; i++) {
                row[i] = rightReader.getValue(i);
            }
            rightRows.add(row);
        }
        
        // Perform join
        for (Object[] leftRow : leftRows) {
            boolean matched = false;
            for (Object[] rightRow : rightRows) {
                Object leftVal = getColumnValue(leftRow, leftColumn);
                Object rightVal = rightReader.getColumnValue(rightRow, rightColumn);
                if (Objects.equals(leftVal, rightVal)) {
                    Object[] combined = new Object[leftRow.length + rightRow.length];
                    System.arraycopy(leftRow, 0, combined, 0, leftRow.length);
                    System.arraycopy(rightRow, 0, combined, leftRow.length, rightRow.length);
                    joinedRows.add(combined);
                    matched = true;
                }
            }
            
            // For LEFT JOIN, include unmatched left rows
            if (!matched && (type == JoinType.LEFT || type == JoinType.FULL)) {
                Object[] combined = new Object[leftRow.length + rightRows.get(0).length];
                System.arraycopy(leftRow, 0, combined, 0, leftRow.length);
                for (int i = leftRow.length; i < combined.length; i++) {
                    combined[i] = null;
                }
                joinedRows.add(combined);
            }
        }
        
        // For RIGHT JOIN, include unmatched right rows
        if (joinType == JoinType.RIGHT || joinType == JoinType.FULL) {
            for (Object[] rightRow : rightRows) {
                boolean matched = false;
                for (Object[] leftRow : leftRows) {
                    Object leftVal = getColumnValue(leftRow, leftColumn);
                    Object rightVal = rightReader.getColumnValue(rightRow, rightColumn);
                    if (Objects.equals(leftVal, rightVal)) {
                        matched = true;
                        break;
                    }
                }
                if (!matched) {
                    Object[] combined = new Object[leftRows.get(0).length + rightRow.length];
                    for (int i = 0; i < leftRows.get(0).length; i++) {
                        combined[i] = null;
                    }
                    System.arraycopy(rightRow, 0, combined, leftRows.get(0).length, rightRow.length);
                    joinedRows.add(combined);
                }
            }
        }
    }
    
    // Aggregation methods
    public void performAggregation(List<String> groupByCols, Map<String, String> aggregates) throws IOException {
        this.groupByColumns = groupByCols;
        this.isAggregated = true;
        this.aggregatedRows = new ArrayList<>();
        
        Map<GroupKey, List<Object[]>> groups = new HashMap<>();
        
        // Group rows
        beforeFirst();
        while (next()) {
            Object[] row = getCurrentRowArray();
            GroupKey key = extractGroupKey(row, groupByCols);
            groups.computeIfAbsent(key, k -> new ArrayList<>()).add(row);
        }
        
        // Compute aggregates for each group
        for (Map.Entry<GroupKey, List<Object[]>> entry : groups.entrySet()) {
            Map<String, Object> result = new LinkedHashMap<>();
            
            // Add group by columns
            for (int i = 0; i < groupByCols.size(); i++) {
                String colName = groupByCols.get(i);
                result.put(colName, entry.getKey().getPart(i));
            }
            
            // Compute aggregates
            for (Map.Entry<String, String> agg : aggregates.entrySet()) {
                String aggFunc = agg.getKey();
                String colName = agg.getValue();
                Object value = computeAggregate(aggFunc, colName, entry.getValue());
                result.put(aggFunc + "(" + colName + ")", value);
            }
            
            aggregatedRows.add(result);
        }
    }
    
    private Object computeAggregate(String function, String column, List<Object[]> rows) {
        switch (function.toUpperCase()) {
            case "COUNT":
                return (long) rows.size();
            case "SUM":
                return rows.stream()
                    .mapToDouble(row -> toDouble(getColumnValue(row, column)))
                    .sum();
            case "AVG":
                return rows.stream()
                    .mapToDouble(row -> toDouble(getColumnValue(row, column)))
                    .average()
                    .orElse(0.0);
            case "MAX":
                return rows.stream()
                    .map(row -> getColumnValue(row, column))
                    .filter(Objects::nonNull)
                    .max((a, b) -> compareValues(a, b))
                    .orElse(null);
            case "MIN":
                return rows.stream()
                    .map(row -> getColumnValue(row, column))
                    .filter(Objects::nonNull)
                    .min((a, b) -> compareValues(a, b))
                    .orElse(null);
            default:
                return null;
        }
    }
    
    private GroupKey extractGroupKey(Object[] row, List<String> groupByCols) {
        List<Object> parts = new ArrayList<>();
        for (String colName : groupByCols) {
            parts.add(getColumnValue(row, colName));
        }
        return new GroupKey(parts);
    }
    
    private static class GroupKey {
        private final List<Object> parts;
        GroupKey(List<Object> parts) { this.parts = parts; }
        List<Object> getParts() { return parts; }
        Object getPart(int index) { return parts.get(index); }
        @Override
        public boolean equals(Object o) {
            if (!(o instanceof GroupKey)) return false;
            return parts.equals(((GroupKey) o).parts);
        }
        @Override
        public int hashCode() { return parts.hashCode(); }
    }
    
    private Object getColumnValue(Object[] row, String columnName) {
        List<DBFField> fields = isJoined ? 
            (currentRecord < joinedRows.size() ? header.getFields() : joinedReader.header.getFields()) : 
            header.getFields();
        
        for (int i = 0; i < fields.size(); i++) {
            if (fields.get(i).getName().equalsIgnoreCase(columnName)) {
                return row[i];
            }
        }
        return null;
    }
    
    private double toDouble(Object value) {
        if (value instanceof Number) return ((Number) value).doubleValue();
        if (value instanceof String) {
            try { return Double.parseDouble((String) value); }
            catch (NumberFormatException e) { return 0.0; }
        }
        return 0.0;
    }
    
    private int compareValues(Object a, Object b) {
        if (a == null && b == null) return 0;
        if (a == null) return -1;
        if (b == null) return 1;
        if (a instanceof Comparable && b instanceof Comparable) {
            return ((Comparable) a).compareTo(b);
        }
        return a.toString().compareTo(b.toString());
    }
    
    // Modified navigation methods for join/aggregation support
    public boolean next() throws IOException {
        if (isJoined) {
            if (joinedRowIndex + 1 < joinedRows.size()) {
                joinedRowIndex++;
                return true;
            }
            return false;
        }
        if (isAggregated) {
            if (aggregatedRowIndex + 1 < aggregatedRows.size()) {
                aggregatedRowIndex++;
                return true;
            }
            return false;
        }
        
        int nextRecord = currentRecord + 1;
        if (nextRecord >= header.getRecordCount()) {
            return false;
        }
        readRecord(nextRecord);
        return true;
    }
    
    public void beforeFirst() {
        if (isJoined) {
            joinedRowIndex = -1;
        } else if (isAggregated) {
            aggregatedRowIndex = -1;
        } else {
            currentRecord = -1;
            currentRecordDeleted = false;
        }
    }
    
    public void absolute(int recordNumber) throws IOException {
        if (isJoined || isAggregated) {
            throw new IOException("Cannot use absolute() on joined/aggregated result set");
        }
        if (recordNumber < 0) {
            recordNumber = header.getRecordCount() + recordNumber + 1;
        }
        if (recordNumber < 1 || recordNumber > header.getRecordCount()) {
            throw new IOException("Record number out of range: " + recordNumber);
        }
        readRecord(recordNumber - 1);
    }
    
    public Object getValue(int columnIndex) throws IOException {
        if (isJoined) {
            if (joinedRowIndex < 0 || joinedRowIndex >= joinedRows.size()) {
                return null;
            }
            Object[] row = joinedRows.get(joinedRowIndex);
            if (columnIndex < 0 || columnIndex >= row.length) {
                return null;
            }
            return row[columnIndex];
        }
        if (isAggregated) {
            if (aggregatedRowIndex < 0 || aggregatedRowIndex >= aggregatedRows.size()) {
                return null;
            }
            Map<String, Object> row = aggregatedRows.get(aggregatedRowIndex);
            String colName = header.getFields().get(columnIndex).getName();
            return row.get(colName);
        }
        
        if (currentRecord < 0 || currentRecord >= header.getRecordCount()) {
            return null;
        }
        
        DBFField field = header.getField(columnIndex);
        int offset = field.getOffset();
        int length = field.getLength();
        
        byte[] data = new byte[length];
        System.arraycopy(recordBuffer, offset, data, 0, length);
        
        if (field.getType() == DBFConstants.FIELD_TYPE_MEMO && memoFile != null) {
            int blockNumber = parseMemoBlockNumber(data);
            try {
                return memoFile.readMemo(blockNumber);
            } catch (SQLException e) {
                throw new IOException("Failed to read memo field: " + e.getMessage(), e);
            }
        }
        
        return parseValue(data, field);
    }
    
    private int parseMemoBlockNumber(byte[] data) {
        int blockNumber = 0;
        for (int i = 0; i < Math.min(data.length, 4); i++) {
            blockNumber |= (data[i] & 0xFF) << (i * 8);
        }
        return blockNumber;
    }
    
    public Object getValue(String columnName) throws IOException {
        DBFField field = header.getField(columnName);
        if (field == null) {
            throw new IOException("Column not found: " + columnName);
        }
        return getValue(field.getPosition() - 1);
    }
    
    private Object parseValue(byte[] data, DBFField field) {
        String str = new String(data, charset).trim();
        
        switch (field.getType()) {
            case DBFConstants.FIELD_TYPE_CHARACTER:
                return str.isEmpty() ? null : str;
            case DBFConstants.FIELD_TYPE_NUMERIC:
            case DBFConstants.FIELD_TYPE_FLOAT:
                if (str.isEmpty()) return null;
                try {
                    if (field.getDecimalCount() > 0 || str.contains(".")) {
                        return Double.parseDouble(str);
                    }
                    return Long.parseLong(str);
                } catch (NumberFormatException e) {
                    return null;
                }
            case DBFConstants.FIELD_TYPE_DATE:
                if (str.length() == 8 && str.matches("\\d{8}")) {
                    try {
                        int year = Integer.parseInt(str.substring(0, 4));
                        int month = Integer.parseInt(str.substring(4, 6));
                        int day = Integer.parseInt(str.substring(6, 8));
                        Calendar cal = Calendar.getInstance();
                        cal.set(year, month - 1, day, 0, 0, 0);
                        cal.set(Calendar.MILLISECOND, 0);
                        return new java.sql.Date(cal.getTimeInMillis());
                    } catch (Exception e) {
                        return null;
                    }
                }
                return null;
            case DBFConstants.FIELD_TYPE_LOGICAL:
                if (str.length() > 0) {
                    char c = str.charAt(0);
                    return c == 'Y' || c == 'y' || c == 'T' || c == 't';
                }
                return false;
            case DBFConstants.FIELD_TYPE_INTEGER:
                if (str.isEmpty()) return null;
                try {
                    return Integer.parseInt(str);
                } catch (NumberFormatException e) {
                    return null;
                }
            default:
                return str;
        }
    }
    
    private void readRecord(int recordIndex) throws IOException {
        long offset = header.getHeaderSize() + (long) recordIndex * header.getRecordSize();
        readBytes(offset, recordBuffer, 0, header.getRecordSize());
        currentRecordDeleted = (recordBuffer[0] == DBFConstants.RECORD_DELETED);
        currentRecord = recordIndex;
    }
    
    private void readBytes(long offset, byte[] buffer, int bufferOffset, int length) throws IOException {
        long pageNum = offset / PAGE_SIZE;
        int pageOffset = (int) (offset % PAGE_SIZE);
        int remaining = length;
        int currentOffset = bufferOffset;
        long currentPos = offset;
        
        while (remaining > 0) {
            pageNum = currentPos / PAGE_SIZE;
            pageOffset = (int) (currentPos % PAGE_SIZE);
            
            byte[] page = pageCache.get(pageNum);
            if (page == null) {
                page = new byte[PAGE_SIZE];
                file.seek(pageNum * PAGE_SIZE);
                int read = file.read(page);
                if (read < PAGE_SIZE) {
                    byte[] trimmed = new byte[read];
                    System.arraycopy(page, 0, trimmed, 0, read);
                    page = trimmed;
                }
                pageCache.put(pageNum, page);
            }
            
            int copySize = Math.min(remaining, page.length - pageOffset);
            System.arraycopy(page, pageOffset, buffer, currentOffset, copySize);
            remaining -= copySize;
            currentOffset += copySize;
            currentPos += copySize;
        }
    }
    
    private Object[] getCurrentRowArray() throws IOException {
        Object[] row = new Object[header.getFieldCount()];
        for (int i = 0; i < header.getFieldCount(); i++) {
            row[i] = getValue(i);
        }
        return row;
    }
    
    public DBFHeader getHeader() { return header; }
    public int getCurrentRecord() { return currentRecord; }
    public boolean isDeleted() { return currentRecordDeleted; }
    public int getRecordCount() { return header.getRecordCount(); }
    public boolean isJoined() { return isJoined; }
    public boolean isAggregated() { return isAggregated; }
    
    public void resetJoinAndAggregation() {
        this.isJoined = false;
        this.isAggregated = false;
        this.joinedRows = null;
        this.aggregatedRows = null;
        this.joinedRowIndex = -1;
        this.aggregatedRowIndex = -1;
    }
    
    @Override
    public void close() throws IOException {
        if (closed.compareAndSet(false, true)) {
            pageCache.clear();
            file.close();
            if (memoFile != null) {
                memoFile.close();
            }
            if (joinedReader != null) {
                joinedReader.close();
            }
        }
    }
    
    // Inner classes for join and aggregation support
    public enum JoinType {
        INNER, LEFT, RIGHT, FULL
    }
    
    private static class PageCache {
        private final int pageSize;
        private final int maxPages;
        private final Map<Long, byte[]> cache;
        
        PageCache(int pageSize, int maxPages) {
            this.pageSize = pageSize;
            this.maxPages = maxPages;
            this.cache = new LinkedHashMap<Long, byte[]>(maxPages, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<Long, byte[]> eldest) {
                    return size() > maxPages;
                }
            };
        }
        
        byte[] get(long pageNumber) { synchronized (cache) { return cache.get(pageNumber); } }
        void put(long pageNumber, byte[] data) { synchronized (cache) { cache.put(pageNumber, data); } }
        void clear() { synchronized (cache) { cache.clear(); } }
    }
}