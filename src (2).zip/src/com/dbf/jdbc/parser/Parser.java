package com.dbf.jdbc.parser;

import com.dbf.jdbc.parser.ast.*;
import java.io.IOException;
import java.io.Reader;
import java.util.*;

/**
 * Simplified LALR(1) parser for SQL SELECT statements
 */
public class Parser {
    private final Lexer lexer;
    private Token currentToken;
    private final List<String> errors = new ArrayList<>();
    
    // Lookahead buffer
    private static final int LOOKAHEAD_SIZE = 3;
    private final Queue<Token> lookahead = new LinkedList<>();
    
    public Parser(Reader reader) throws IOException {
        this.lexer = new Lexer(reader);
        advance();
        fillLookahead();
    }
    
    private void advance() {
        currentToken = lexer.nextToken();
        lookahead.offer(currentToken);
        if (lookahead.size() > LOOKAHEAD_SIZE) {
            lookahead.poll();
        }
    }
    
    private void fillLookahead() {
        while (lookahead.size() < LOOKAHEAD_SIZE && currentToken.getType() != TokenType.EOF) {
            lookahead.offer(currentToken);
            currentToken = lexer.nextToken();
        }
    }
    
    private Token lookahead(int k) {
        if (k <= 0) return currentToken;
        int index = 0;
        for (Token t : lookahead) {
            if (index == k) return t;
            index++;
        }
        return new Token(TokenType.EOF, null, -1, -1);
    }
    
    private boolean match(TokenType type) {
        if (currentToken.getType() == type) {
            advance();
            fillLookahead();
            return true;
        }
        return false;
    }
    
    private void expect(TokenType type) throws ParseException {
        if (!match(type)) {
            throw new ParseException("Expected " + type + " but found " + currentToken.getType() + 
                " at line " + currentToken.getLine() + ", column " + currentToken.getColumn());
        }
    }
    
    private boolean isOperator(Token token) {
        TokenType type = token.getType();
        return type == TokenType.EQ || type == TokenType.LT || type == TokenType.GT ||
               type == TokenType.LE || type == TokenType.GE || type == TokenType.NE ||
               type == TokenType.LIKE || type == TokenType.IN;
    }
    
    public SelectNode parseSelect() throws ParseException {
        SelectNode select = new SelectNode();
        
        // SELECT
        expect(TokenType.SELECT);
        
        // Columns
        parseSelectList(select);
        
        // FROM
        expect(TokenType.FROM);
        parseFrom(select);
        
        // WHERE (optional)
        if (currentToken.getType() == TokenType.WHERE) {
            match(TokenType.WHERE);
            parseWhere(select);
        }
        
        // ORDER BY (optional)
        if (currentToken.getType() == TokenType.ORDER) {
            match(TokenType.ORDER);
            expect(TokenType.BY);
            parseOrderBy(select);
        }
        
        return select;
    }
    
    private void parseSelectList(SelectNode select) throws ParseException {
        do {
            if (currentToken.getType() == TokenType.STAR) {
                ColumnNode star = new ColumnNode(currentToken);
                select.addColumn(star);
                match(TokenType.STAR);
            } else {
                ColumnNode column = parseColumn();
                select.addColumn(column);
                
                // Optional alias
                if (currentToken.getValue() != null && 
                    currentToken.getValue().equalsIgnoreCase("as")) {
                    match(currentToken.getType());
                    column.setAlias(currentToken.getValue());
                    expect(TokenType.IDENTIFIER);
                }
            }
        } while (match(TokenType.COMMA));
    }
    
    private ColumnNode parseColumn() throws ParseException {
        ColumnNode column = new ColumnNode(currentToken);
        
        // Handle table.column format
        if (lookahead(1).getType() == TokenType.DOT) {
            column.setTableName(currentToken.getValue());
            match(TokenType.IDENTIFIER);
            match(TokenType.DOT);
            column = new ColumnNode(currentToken);
            column.setTableName(column.getTableName());
            expect(TokenType.IDENTIFIER);
        } else {
            expect(TokenType.IDENTIFIER);
        }
        
        return column;
    }
    
    private void parseFrom(SelectNode select) throws ParseException {
        FromNode from = new FromNode();
        from.setTableName(currentToken.getValue());
        expect(TokenType.IDENTIFIER);
        
        // Optional table alias
        if (currentToken.getType() == TokenType.IDENTIFIER && 
            lookahead(1).getType() != TokenType.WHERE &&
            lookahead(1).getType() != TokenType.ORDER) {
            from.setAlias(currentToken.getValue());
            advance();
        }
        
        select.setFrom(from);
    }
    
    private void parseWhere(SelectNode select) throws ParseException {
        WhereNode where = new WhereNode();
        ExpressionNode expr = parseExpression();
        where.setCondition(expr);
        select.setWhere(where);
    }
    
    private ExpressionNode parseExpression() throws ParseException {
        ExpressionNode left = parseTerm();
        
        while (currentToken.getType() == TokenType.OR) {
            ExpressionNode node = new ExpressionNode(currentToken);
            match(TokenType.OR);
            node.setLeft(left);
            node.setRight(parseTerm());
            left = node;
        }
        
        return left;
    }
    
    private ExpressionNode parseTerm() throws ParseException {
        ExpressionNode left = parseFactor();
        
        while (currentToken.getType() == TokenType.AND) {
            ExpressionNode node = new ExpressionNode(currentToken);
            match(TokenType.AND);
            node.setLeft(left);
            node.setRight(parseFactor());
            left = node;
        }
        
        return left;
    }
    
    private ExpressionNode parseFactor() throws ParseException {
        // Handle NOT operator
        if (currentToken.getType() == TokenType.NOT) {
            ExpressionNode node = new ExpressionNode(currentToken);
            match(TokenType.NOT);
            node.setLeft(parseAtom());
            return node;
        }
        
        return parseAtom();
    }
    
    private ExpressionNode parseAtom() throws ParseException {
        // Parenthesized expression
        if (currentToken.getType() == TokenType.LPAREN) {
            match(TokenType.LPAREN);
            ExpressionNode expr = parseExpression();
            expect(TokenType.RPAREN);
            return expr;
        }
        
        // Comparison expression
        ExpressionNode left = parsePrimary();
        
        if (isOperator(currentToken)) {
            ExpressionNode node = new ExpressionNode(currentToken);
            match(currentToken.getType());
            node.setLeft(left);
            node.setRight(parsePrimary());
            return node;
        }
        
        return left;
    }
    
 // In Parser.java, update the parsePrimary() method:

    private ExpressionNode parsePrimary() throws ParseException {
        if (currentToken.getType() == TokenType.IDENTIFIER) {
            // Check for NULL
            if (currentToken.getValue().equalsIgnoreCase("null")) {
                ExpressionNode node = new ExpressionNode(currentToken);
                match(TokenType.IDENTIFIER);
                return node;
            }
            
            // Check for table.column format
            if (lookahead(1).getType() == TokenType.DOT) {
                String table = currentToken.getValue();
                match(TokenType.IDENTIFIER);
                match(TokenType.DOT);
                ExpressionNode node = new ExpressionNode(currentToken);
                node.setTableName(table);
                node.setColumnName(currentToken.getValue());
                expect(TokenType.IDENTIFIER);
                return node;
            }
            
            // Regular column
            ExpressionNode node = new ExpressionNode(currentToken);
            node.setColumnName(currentToken.getValue());
            expect(TokenType.IDENTIFIER);
            return node;
        }
        else if (currentToken.getType() == TokenType.NUMBER) {
            ExpressionNode node = new ExpressionNode(currentToken);
            node.setLiteralValue(parseNumber(currentToken.getValue()));
            expect(TokenType.NUMBER);
            return node;
        }
        else if (currentToken.getType() == TokenType.STRING) {
            ExpressionNode node = new ExpressionNode(currentToken);
            node.setLiteralValue(currentToken.getValue());
            expect(TokenType.STRING);
            return node;
        }
        else if (currentToken.getType() == TokenType.NULL) {
            ExpressionNode node = new ExpressionNode(currentToken);
            node.setLiteralValue(null);
            match(TokenType.NULL);
            return node;
        }
        
        throw new ParseException("Unexpected token: " + currentToken);
    }

    private Object parseNumber(String value) {
        if (value.contains(".")) {
            return Double.parseDouble(value);
        }
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException e) {
            return Double.parseDouble(value);
        }
    }
    
    private void parseOrderBy(SelectNode select) throws ParseException {
        OrderByNode orderBy = new OrderByNode();
        
        do {
            String columnName = currentToken.getValue();
            expect(TokenType.IDENTIFIER);
            
            boolean ascending = true;
            if (currentToken.getType() == TokenType.ASC) {
                match(TokenType.ASC);
            } else if (currentToken.getType() == TokenType.DESC) {
                ascending = false;
                match(TokenType.DESC);
            }
            
            orderBy.addItem(new OrderByNode.OrderItem(columnName, ascending));
        } while (match(TokenType.COMMA));
        
        select.setOrderBy(orderBy);
    }
    
    public List<String> getErrors() {
        return errors;
    }
    
    public static class ParseException extends Exception {
        public ParseException(String message) {
            super(message);
        }
    }
}