package com.dbf.jdbc.resultset;

import com.dbf.jdbc.parser.ast.AggregateNode;
import com.dbf.jdbc.parser.ast.GroupByNode;
import com.dbf.jdbc.parser.ast.SelectNode;
import java.util.*;

/**
 * Handles GROUP BY and aggregate functions (COUNT, SUM, AVG, MAX, MIN)
 */
public class AggregateEngine {
    private final List<String> groupByColumns;
    private final Map<String, AggregateInfo> aggregates;
    private List<Map<String, Object>> aggregatedResults;
    private boolean isAggregated = false;
    
    private static class AggregateInfo {
        final String function;
        final String columnName;
        double sum = 0;
        long count = 0;
        Object max = null;
        Object min = null;
        
        AggregateInfo(String function, String columnName) {
            this.function = function.toUpperCase();
            this.columnName = columnName;
        }
        
        void accumulate(Object value) {
            if (value == null) return;
            
            count++;
            Number num = null;
            if (value instanceof Number) {
                num = (Number) value;
                sum += num.doubleValue();
            }
            
            // For MAX/MIN
            if (max == null || compareValues(value, max) > 0) max = value;
            if (min == null || compareValues(value, min) < 0) min = value;
        }
        
        Object getResult() {
            switch (function) {
                case "COUNT": return count;
                case "SUM": return sum;
                case "AVG": return count > 0 ? sum / count : 0.0;
                case "MAX": return max;
                case "MIN": return min;
                default: return null;
            }
        }
        
        @SuppressWarnings({"unchecked", "rawtypes"})
        private int compareValues(Object a, Object b) {
            if (a == null && b == null) return 0;
            if (a == null) return -1;
            if (b == null) return 1;
            if (a instanceof Comparable && b instanceof Comparable) {
                return ((Comparable) a).compareTo(b);
            }
            return a.toString().compareTo(b.toString());
        }
    }
    
    public AggregateEngine(SelectNode selectNode, RowProjector projector) {
        this.groupByColumns = new ArrayList<>();
        this.aggregates = new LinkedHashMap<>();
        
        if (selectNode != null) {
            if (selectNode.getGroupBy() != null) {
                groupByColumns.addAll(selectNode.getGroupBy().getColumnNames());
            }
            
            if (selectNode.getAggregates() != null) {
                for (AggregateNode agg : selectNode.getAggregates()) {
                    String colName = agg.getColumn() != null ? agg.getColumn().getColumnName() : "*";
                    aggregates.put(agg.getFunction() + "(" + colName + ")", 
                                   new AggregateInfo(agg.getFunction(), colName));
                }
            }
        }
    }
    
    public boolean hasAggregation() {
        return !aggregates.isEmpty();
    }
    
    public boolean hasGroupBy() {
        return !groupByColumns.isEmpty();
    }
    
    public List<Map<String, Object>> aggregate(List<Object[]> rows, RowProjector projector) {
        if (!hasAggregation()) {
            isAggregated = false;
            return null;
        }
        
        Map<GroupKey, List<Object[]>> groups = new HashMap<>();
        
        // Group rows
        for (Object[] row : rows) {
            GroupKey key = extractGroupKey(row, projector);
            groups.computeIfAbsent(key, k -> new ArrayList<>()).add(row);
        }
        
        // Compute aggregates for each group
        aggregatedResults = new ArrayList<>();
        for (Map.Entry<GroupKey, List<Object[]>> entry : groups.entrySet()) {
            Map<String, Object> result = new LinkedHashMap<>();
            
            // Add group by columns
            GroupKey key = entry.getKey();
            for (int i = 0; i < groupByColumns.size(); i++) {
                result.put(groupByColumns.get(i), key.getPart(i));
            }
            
            // Reset aggregates
            for (AggregateInfo agg : aggregates.values()) {
                agg.sum = 0;
                agg.count = 0;
                agg.max = null;
                agg.min = null;
            }
            
            // Accumulate
            for (Object[] row : entry.getValue()) {
                for (Map.Entry<String, AggregateInfo> aggEntry : aggregates.entrySet()) {
                    String colName = aggEntry.getValue().columnName;
                    int colIdx = projector.getColumnIndex(colName);
                    Object value = (colIdx >= 0 && colIdx < row.length) ? row[colIdx] : null;
                    aggEntry.getValue().accumulate(value);
                }
            }
            
            // Add results
            for (Map.Entry<String, AggregateInfo> aggEntry : aggregates.entrySet()) {
                result.put(aggEntry.getKey(), aggEntry.getValue().getResult());
            }
            
            aggregatedResults.add(result);
        }
        
        isAggregated = true;
        return aggregatedResults;
    }
    
    private GroupKey extractGroupKey(Object[] row, RowProjector projector) {
        List<Object> parts = new ArrayList<>();
        for (String colName : groupByColumns) {
            int colIdx = projector.getColumnIndex(colName);
            Object value = (colIdx >= 0 && colIdx < row.length) ? row[colIdx] : null;
            parts.add(value);
        }
        return new GroupKey(parts);
    }
    
    public boolean isAggregated() {
        return isAggregated;
    }
    
    public List<Map<String, Object>> getAggregatedResults() {
        return aggregatedResults;
    }
    
    private static class GroupKey {
        private final List<Object> parts;
        
        GroupKey(List<Object> parts) {
            this.parts = parts;
        }
        
        List<Object> getParts() { return parts; }
        Object getPart(int index) { return parts.get(index); }
        
        @Override
        public boolean equals(Object o) {
            if (!(o instanceof GroupKey)) return false;
            return parts.equals(((GroupKey) o).parts);
        }
        
        @Override
        public int hashCode() {
            return parts.hashCode();
        }
    }
}