package com.dbf.jdbc;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.dbf.jdbc.dbf.DBFField;
import com.dbf.jdbc.dbf.DBFReader;
import com.dbf.jdbc.parser.TokenType;
import com.dbf.jdbc.parser.ast.ColumnNode;
import com.dbf.jdbc.parser.ast.ExpressionNode;
import com.dbf.jdbc.parser.ast.OrderByNode;
import com.dbf.jdbc.parser.ast.SelectNode;

/**
 * JDBC ResultSet implementation for DBF with full feature support
 * - SELECT with WHERE, ORDER BY
 * - JOIN support (INNER, LEFT, RIGHT, FULL)
 * - GROUP BY with aggregate functions (COUNT, SUM, AVG, MAX, MIN)
 * - HAVING clause support
 * - Index support (NDX, MDX)
 * - Memo field support (.dbt, .fpt)
 */
public class DBFResultSet implements ResultSet {
    private final DBFReader reader;
    private final SelectNode selectNode;
    private final List<Integer> selectedColumns;
    private final Map<String, Integer> columnNameToIndex;
    private final List<String> columnNames;
    private final List<String> columnLabels;
    private final List<Integer> orderByColumns;
    private final List<Boolean> orderByAscending;
    
    // WHERE clause support
    private ExpressionNode whereCondition;
    
    // Row management
    private List<Integer> filteredRowIndices;
    private int currentRow = -1;
    private boolean wasNull = false;
    private boolean closed = false;
    private SQLWarning warnings = null;
    
    // Fetch settings
    private int fetchSize = 100;
    private int fetchDirection = FETCH_FORWARD;
    private int type = TYPE_FORWARD_ONLY;
    private int concurrency = CONCUR_READ_ONLY;
    
    // For order by and filtering
    private List<Object[]> cachedRows;
    private int totalRows = 0;
    
    public DBFResultSet(DBFReader reader, SelectNode selectNode) throws SQLException {
        this.reader = reader;
        this.selectNode = selectNode;
        this.orderByColumns = new ArrayList<>();
        this.orderByAscending = new ArrayList<>();
        
        // Determine selected columns
        this.selectedColumns = new ArrayList<>();
        this.columnNames = new ArrayList<>();
        this.columnLabels = new ArrayList<>();
        this.columnNameToIndex = new HashMap<>();
        
        List<DBFField> fields = reader.getHeader().getFields();
        
        if (selectNode != null && selectNode.getColumns().size() == 1 && 
            selectNode.getColumns().get(0).isStar()) {
            // SELECT *
            for (int i = 0; i < fields.size(); i++) {
                selectedColumns.add(i);
                columnNames.add(fields.get(i).getName());
                columnLabels.add(fields.get(i).getName());
                columnNameToIndex.put(fields.get(i).getName().toLowerCase(), i);
            }
        } else if (selectNode != null) {
            // SELECT specific columns
            for (ColumnNode col : selectNode.getColumns()) {
                String colName = col.getColumnName();
                int idx = -1;
                for (int i = 0; i < fields.size(); i++) {
                    if (fields.get(i).getName().equalsIgnoreCase(colName)) {
                        idx = i;
                        break;
                    }
                }
                if (idx == -1) {
                    throw new SQLException("Column not found: " + colName);
                }
                selectedColumns.add(idx);
                columnNames.add(fields.get(idx).getName());
                columnLabels.add(col.getAlias() != null ? col.getAlias() : fields.get(idx).getName());
                columnNameToIndex.put(columnLabels.get(columnLabels.size() - 1).toLowerCase(), 
                                      selectedColumns.size() - 1);
            }
        }
        
        // Parse ORDER BY
        if (selectNode != null && selectNode.getOrderBy() != null) {
            for (OrderByNode.OrderItem item : selectNode.getOrderBy().getItems()) {
                int colIdx = getColumnIndex(item.getColumnName());
                if (colIdx >= 0) {
                    orderByColumns.add(colIdx);
                    orderByAscending.add(item.isAscending());
                }
            }
        }
        
        // Load and filter rows
        loadRows();
    }
    
    public void setWhereCondition(ExpressionNode condition) {
        this.whereCondition = condition;
        // Reload rows with new filter
        try {
            loadRows();
        } catch (SQLException e) {
            // Handle silently, will be caught on next operation
        }
    }
    
    private void loadRows() throws SQLException {
        List<Object[]> allRows = new ArrayList<>();
        
        try {
            if (reader.isJoined()) {
                // For joined result sets, rows are already loaded
                reader.beforeFirst();
                while (reader.next()) {
                    Object[] row = new Object[selectedColumns.size()];
                    for (int i = 0; i < selectedColumns.size(); i++) {
                        row[i] = reader.getValue(selectedColumns.get(i));
                    }
                    allRows.add(row);
                }
            } else if (reader.isAggregated()) {
                // For aggregated result sets
                reader.beforeFirst();
                while (reader.next()) {
                    Object[] row = new Object[selectedColumns.size()];
                    for (int i = 0; i < selectedColumns.size(); i++) {
                        row[i] = reader.getValue(selectedColumns.get(i));
                    }
                    allRows.add(row);
                }
            } else {
                // Normal result set
                reader.beforeFirst();
                while (reader.next()) {
                    // Apply WHERE clause filter
                    if (whereCondition == null || evaluateWhereCondition()) {
                        Object[] row = new Object[selectedColumns.size()];
                        for (int i = 0; i < selectedColumns.size(); i++) {
                            row[i] = reader.getValue(selectedColumns.get(i));
                        }
                        allRows.add(row);
                    }
                }
            }
        } catch (IOException e) {
            throw new SQLException("Error loading rows: " + e.getMessage(), e);
        }
        
        // Apply ORDER BY
        if (!orderByColumns.isEmpty()) {
            allRows.sort((a, b) -> {
                for (int i = 0; i < orderByColumns.size(); i++) {
                    int colIdx = orderByColumns.get(i);
                    Object valA = (colIdx < a.length) ? a[colIdx] : null;
                    Object valB = (colIdx < b.length) ? b[colIdx] : null;
                    int cmp = compareValues(valA, valB);
                    if (cmp != 0) {
                        return orderByAscending.get(i) ? cmp : -cmp;
                    }
                }
                return 0;
            });
        }
        
        // Apply MAX ROWS limit
        if (selectNode != null) {
            Statement stmt = getStatement();
            if (stmt != null && stmt.getMaxRows() > 0 && allRows.size() > stmt.getMaxRows()) {
                allRows = allRows.subList(0, stmt.getMaxRows());
            }
        }
        
        this.cachedRows = allRows;
        this.totalRows = allRows.size();
        this.filteredRowIndices = new ArrayList<>();
        for (int i = 0; i < totalRows; i++) {
            filteredRowIndices.add(i);
        }
        this.currentRow = -1;
    }
    
    private boolean evaluateWhereCondition() throws IOException {
        if (whereCondition == null) return true;
        return evaluateExpression(whereCondition);
    }
    
    private boolean evaluateExpression(ExpressionNode node) throws IOException {
        if (node == null) return true;
        
        if (node.isBinaryOp()) {
            Object left = evaluateValue(node.getLeft());
            Object right = evaluateValue(node.getRight());
            return compareForWhere(left, right, node.getType());
        } else if (node.getType() == TokenType.NOT) {
            return !evaluateExpression((ExpressionNode) node.getLeft());
        } else {
            Object val = evaluateValue(node);
            if (val instanceof Boolean) {
                return (Boolean) val;
            }
            return val != null;
        }
    }
    
    private Object evaluateValue(ExpressionNode node) throws IOException {
        if (node == null) return null;
        
        if (node.isLiteral()) {
            switch (node.getType()) {
                case NUMBER:
                    String val = node.getValue();
                    if (val.contains(".")) {
                        return Double.parseDouble(val);
                    }
                    try {
                        return Long.parseLong(val);
                    } catch (NumberFormatException e) {
                        return Double.parseDouble(val);
                    }
                case STRING:
                    return node.getValue();
                case NULL:
                    return null;
                default:
                    return node.getValue();
            }
        }
        
        if (node.isColumn()) {
            String columnName = node.getValue();
            int colIdx = getColumnIndex(columnName);
            if (colIdx >= 0) {
                try {
                    return reader.getValue(selectedColumns.get(colIdx));
                } catch (IOException e) {
                    return null;
                }
            }
            return null;
        }
        
        if (node.isBinaryOp()) {
            Object left = evaluateValue(node.getLeft());
            Object right = evaluateValue(node.getRight());
            return applyOperator(left, right, node.getType());
        }
        
        return null;
    }
    
    private Object applyOperator(Object left, Object right, TokenType op) {
        if (left == null || right == null) return null;
        
        switch (op) {
            case EQ: return left.equals(right);
            case NE: return !left.equals(right);
            case LT: return compareNumeric(left, right) < 0;
            case GT: return compareNumeric(left, right) > 0;
            case LE: return compareNumeric(left, right) <= 0;
            case GE: return compareNumeric(left, right) >= 0;
            default: return null;
        }
    }
    
    private boolean compareForWhere(Object left, Object right, TokenType op) {
        if (left == null && right == null) {
            return op == TokenType.EQ;
        }
        if (left == null || right == null) {
            return op == TokenType.NE;
        }
        
        try {
            double lnum = toDouble(left);
            double rnum = toDouble(right);
            
            switch (op) {
                case EQ: return Math.abs(lnum - rnum) < 1e-10;
                case NE: return Math.abs(lnum - rnum) >= 1e-10;
                case LT: return lnum < rnum;
                case GT: return lnum > rnum;
                case LE: return lnum <= rnum;
                case GE: return lnum >= rnum;
                default: return false;
            }
        } catch (NumberFormatException e) {
            String lstr = left.toString();
            String rstr = right.toString();
            
            switch (op) {
                case EQ: return lstr.equalsIgnoreCase(rstr);
                case NE: return !lstr.equalsIgnoreCase(rstr);
                case LT: return lstr.compareToIgnoreCase(rstr) < 0;
                case GT: return lstr.compareToIgnoreCase(rstr) > 0;
                case LE: return lstr.compareToIgnoreCase(rstr) <= 0;
                case GE: return lstr.compareToIgnoreCase(rstr) >= 0;
                default: return false;
            }
        }
    }
    
    private double toDouble(Object value) {
        if (value instanceof Number) return ((Number) value).doubleValue();
        return Double.parseDouble(value.toString());
    }
    
    private int compareNumeric(Object left, Object right) {
        double lnum = toDouble(left);
        double rnum = toDouble(right);
        return Double.compare(lnum, rnum);
    }
    
    private int compareValues(Object a, Object b) {
        if (a == null && b == null) return 0;
        if (a == null) return -1;
        if (b == null) return 1;
        
        if (a instanceof Number && b instanceof Number) {
            return Double.compare(((Number) a).doubleValue(), ((Number) b).doubleValue());
        }
        if (a instanceof Comparable && b instanceof Comparable) {
            return ((Comparable) a).compareTo(b);
        }
        return a.toString().compareTo(b.toString());
    }
    
    private int getColumnIndex(String name) {
        Integer idx = columnNameToIndex.get(name.toLowerCase());
        return idx != null ? idx : -1;
    }
    
    private Object getCurrentValue(int columnIndex) throws SQLException {
        checkClosed();
        if (currentRow < 0 || currentRow >= totalRows) {
            throw new SQLException("No current row");
        }
        
        int colIdx = columnIndex - 1;
        if (colIdx < 0 || colIdx >= selectedColumns.size()) {
            throw new SQLException("Invalid column index: " + columnIndex);
        }
        
        Object value = cachedRows.get(filteredRowIndices.get(currentRow))[colIdx];
        wasNull = (value == null);
        return value;
    }
    
    private String getColumnName(int columnIndex) throws SQLException {
        if (columnIndex < 1 || columnIndex > columnNames.size()) {
            throw new SQLException("Invalid column index: " + columnIndex);
        }
        return columnNames.get(columnIndex - 1);
    }
    
    private void checkClosed() throws SQLException {
        if (closed) {
            throw new SQLException("ResultSet is closed");
        }
    }
    
    // ==================== ResultSet Interface Implementation ====================
    
    @Override
    public boolean next() throws SQLException {
        checkClosed();
        if (currentRow + 1 < totalRows) {
            currentRow++;
            return true;
        }
        return false;
    }
    
    @Override
    public void close() throws SQLException {
        if (!closed) {
            closed = true;
            try {
                reader.close();
            } catch (IOException e) {
                throw new SQLException("Error closing DBF reader: " + e.getMessage(), e);
            }
        }
    }
    
    @Override
    public boolean wasNull() throws SQLException {
        return wasNull;
    }
    
    @Override
    public String getString(int columnIndex) throws SQLException {
        Object value = getCurrentValue(columnIndex);
        return value != null ? value.toString() : null;
    }
    
    @Override
    public boolean getBoolean(int columnIndex) throws SQLException {
        Object value = getCurrentValue(columnIndex);
        if (value == null) return false;
        if (value instanceof Boolean) return (Boolean) value;
        if (value instanceof Number) return ((Number) value).intValue() != 0;
        String s = value.toString();
        return s.equalsIgnoreCase("Y") || s.equalsIgnoreCase("T") || s.equalsIgnoreCase("TRUE");
    }
    
    @Override
    public byte getByte(int columnIndex) throws SQLException {
        Number n = getNumber(columnIndex);
        return n != null ? n.byteValue() : 0;
    }
    
    @Override
    public short getShort(int columnIndex) throws SQLException {
        Number n = getNumber(columnIndex);
        return n != null ? n.shortValue() : 0;
    }
    
    @Override
    public int getInt(int columnIndex) throws SQLException {
        Number n = getNumber(columnIndex);
        return n != null ? n.intValue() : 0;
    }
    
    @Override
    public long getLong(int columnIndex) throws SQLException {
        Number n = getNumber(columnIndex);
        return n != null ? n.longValue() : 0;
    }
    
    @Override
    public float getFloat(int columnIndex) throws SQLException {
        Number n = getNumber(columnIndex);
        return n != null ? n.floatValue() : 0;
    }
    
    @Override
    public double getDouble(int columnIndex) throws SQLException {
        Number n = getNumber(columnIndex);
        return n != null ? n.doubleValue() : 0;
    }
    
    private Number getNumber(int columnIndex) throws SQLException {
        Object value = getCurrentValue(columnIndex);
        if (value == null) return null;
        if (value instanceof Number) return (Number) value;
        try {
            String s = value.toString().trim();
            if (s.isEmpty()) return null;
            if (s.contains(".")) {
                return Double.parseDouble(s);
            }
            return Long.parseLong(s);
        } catch (NumberFormatException e) {
            return null;
        }
    }
    
    @Override
    public BigDecimal getBigDecimal(int columnIndex, int scale) throws SQLException {
        Number n = getNumber(columnIndex);
        if (n == null) return null;
        BigDecimal bd = BigDecimal.valueOf(n.doubleValue());
        return bd.setScale(scale, BigDecimal.ROUND_HALF_UP);
    }
    
    @Override
    public byte[] getBytes(int columnIndex) throws SQLException {
        Object value = getCurrentValue(columnIndex);
        if (value == null) return null;
        if (value instanceof byte[]) return (byte[]) value;
        return value.toString().getBytes();
    }
    
    @Override
    public Date getDate(int columnIndex) throws SQLException {
        Object value = getCurrentValue(columnIndex);
        if (value == null) return null;
        if (value instanceof Date) return (Date) value;
        if (value instanceof java.util.Date) return new Date(((java.util.Date) value).getTime());
        try {
            return Date.valueOf(value.toString());
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
    
    @Override
    public Time getTime(int columnIndex) throws SQLException {
        Date date = getDate(columnIndex);
        return date != null ? new Time(date.getTime()) : null;
    }
    
    @Override
    public Timestamp getTimestamp(int columnIndex) throws SQLException {
        Date date = getDate(columnIndex);
        return date != null ? new Timestamp(date.getTime()) : null;
    }
    
    @Override
    public InputStream getAsciiStream(int columnIndex) throws SQLException {
        String s = getString(columnIndex);
        return s != null ? new java.io.ByteArrayInputStream(s.getBytes()) : null;
    }
    
    @Override
    public InputStream getBinaryStream(int columnIndex) throws SQLException {
        byte[] bytes = getBytes(columnIndex);
        return bytes != null ? new java.io.ByteArrayInputStream(bytes) : null;
    }
    
    @Override
    public String getString(String columnLabel) throws SQLException {
        return getString(findColumn(columnLabel));
    }
    
    @Override
    public boolean getBoolean(String columnLabel) throws SQLException {
        return getBoolean(findColumn(columnLabel));
    }
    
    @Override
    public byte getByte(String columnLabel) throws SQLException {
        return getByte(findColumn(columnLabel));
    }
    
    @Override
    public short getShort(String columnLabel) throws SQLException {
        return getShort(findColumn(columnLabel));
    }
    
    @Override
    public int getInt(String columnLabel) throws SQLException {
        return getInt(findColumn(columnLabel));
    }
    
    @Override
    public long getLong(String columnLabel) throws SQLException {
        return getLong(findColumn(columnLabel));
    }
    
    @Override
    public float getFloat(String columnLabel) throws SQLException {
        return getFloat(findColumn(columnLabel));
    }
    
    @Override
    public double getDouble(String columnLabel) throws SQLException {
        return getDouble(findColumn(columnLabel));
    }
    
    @Override
    public BigDecimal getBigDecimal(String columnLabel, int scale) throws SQLException {
        return getBigDecimal(findColumn(columnLabel), scale);
    }
    
    @Override
    public byte[] getBytes(String columnLabel) throws SQLException {
        return getBytes(findColumn(columnLabel));
    }
    
    @Override
    public Date getDate(String columnLabel) throws SQLException {
        return getDate(findColumn(columnLabel));
    }
    
    @Override
    public Time getTime(String columnLabel) throws SQLException {
        return getTime(findColumn(columnLabel));
    }
    
    @Override
    public Timestamp getTimestamp(String columnLabel) throws SQLException {
        return getTimestamp(findColumn(columnLabel));
    }
    
    @Override
    public InputStream getAsciiStream(String columnLabel) throws SQLException {
        return getAsciiStream(findColumn(columnLabel));
    }
    
    @Override
    public InputStream getBinaryStream(String columnLabel) throws SQLException {
        return getBinaryStream(findColumn(columnLabel));
    }
    
    @Override
    public SQLWarning getWarnings() throws SQLException {
        return warnings;
    }
    
    @Override
    public void clearWarnings() throws SQLException {
        warnings = null;
    }
    
    @Override
    public String getCursorName() throws SQLException {
        throw new SQLFeatureNotSupportedException("getCursorName not supported");
    }
    
    @Override
    public ResultSetMetaData getMetaData() throws SQLException {
        return new DBFResultSetMetaData(this, reader.getHeader().getFields(), selectedColumns, columnLabels);
    }
    
    @Override
    public Object getObject(int columnIndex) throws SQLException {
        return getCurrentValue(columnIndex);
    }
    
    @Override
    public Object getObject(String columnLabel) throws SQLException {
        return getObject(findColumn(columnLabel));
    }
    
    @Override
    public int findColumn(String columnLabel) throws SQLException {
        Integer idx = columnNameToIndex.get(columnLabel.toLowerCase());
        if (idx == null) {
            throw new SQLException("Column not found: " + columnLabel);
        }
        return idx + 1;
    }
    
    @Override
    public boolean isBeforeFirst() throws SQLException {
        return currentRow == -1 && totalRows > 0;
    }
    
    @Override
    public boolean isAfterLast() throws SQLException {
        return currentRow >= totalRows;
    }
    
    @Override
    public boolean isFirst() throws SQLException {
        return currentRow == 0;
    }
    
    @Override
    public boolean isLast() throws SQLException {
        return currentRow == totalRows - 1 && currentRow >= 0;
    }
    
    @Override
    public void beforeFirst() throws SQLException {
        checkClosed();
        currentRow = -1;
    }
    
    @Override
    public void afterLast() throws SQLException {
        checkClosed();
        currentRow = totalRows;
    }
    
    @Override
    public boolean first() throws SQLException {
        checkClosed();
        if (totalRows > 0) {
            currentRow = 0;
            return true;
        }
        return false;
    }
    
    @Override
    public boolean last() throws SQLException {
        checkClosed();
        if (totalRows > 0) {
            currentRow = totalRows - 1;
            return true;
        }
        return false;
    }
    
    @Override
    public int getRow() throws SQLException {
        return isBeforeFirst() || isAfterLast() ? 0 : currentRow + 1;
    }
    
    @Override
    public boolean absolute(int row) throws SQLException {
        checkClosed();
        if (row == 0) {
            beforeFirst();
            return false;
        }
        int target = row > 0 ? row - 1 : totalRows + row;
        if (target >= 0 && target < totalRows) {
            currentRow = target;
            return true;
        }
        if (target < 0) {
            beforeFirst();
        } else {
            afterLast();
        }
        return false;
    }
    
    @Override
    public boolean relative(int rows) throws SQLException {
        return absolute(getRow() + rows);
    }
    
    @Override
    public boolean previous() throws SQLException {
        if (currentRow > 0) {
            currentRow--;
            return true;
        }
        if (currentRow == 0) {
            beforeFirst();
        }
        return false;
    }
    
    @Override
    public void setFetchDirection(int direction) throws SQLException {
        if (direction != FETCH_FORWARD && type == TYPE_FORWARD_ONLY) {
            throw new SQLException("Cannot set fetch direction on TYPE_FORWARD_ONLY result set");
        }
        this.fetchDirection = direction;
    }
    
    @Override
    public int getFetchDirection() throws SQLException {
        return fetchDirection;
    }
    
    @Override
    public void setFetchSize(int rows) throws SQLException {
        if (rows < 0) {
            throw new SQLException("Fetch size cannot be negative");
        }
        this.fetchSize = rows;
    }
    
    @Override
    public int getFetchSize() throws SQLException {
        return fetchSize;
    }
    
    @Override
    public int getType() throws SQLException {
        return type;
    }
    
    @Override
    public int getConcurrency() throws SQLException {
        return concurrency;
    }
    
    @Override
    public boolean rowUpdated() throws SQLException {
        return false;
    }
    
    @Override
    public boolean rowInserted() throws SQLException {
        return false;
    }
    
    @Override
    public boolean rowDeleted() throws SQLException {
        return false;
    }
    
    @Override
    public void updateNull(int columnIndex) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateBoolean(int columnIndex, boolean x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateByte(int columnIndex, byte x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateShort(int columnIndex, short x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateInt(int columnIndex, int x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateLong(int columnIndex, long x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateFloat(int columnIndex, float x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateDouble(int columnIndex, double x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateBigDecimal(int columnIndex, BigDecimal x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateString(int columnIndex, String x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateBytes(int columnIndex, byte[] x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateDate(int columnIndex, Date x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateTime(int columnIndex, Time x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateTimestamp(int columnIndex, Timestamp x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateAsciiStream(int columnIndex, InputStream x, int length) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateBinaryStream(int columnIndex, InputStream x, int length) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateCharacterStream(int columnIndex, Reader x, int length) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateObject(int columnIndex, Object x, int scaleOrLength) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateObject(int columnIndex, Object x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateNull(String columnLabel) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateBoolean(String columnLabel, boolean x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateByte(String columnLabel, byte x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateShort(String columnLabel, short x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateInt(String columnLabel, int x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateLong(String columnLabel, long x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateFloat(String columnLabel, float x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateDouble(String columnLabel, double x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateBigDecimal(String columnLabel, BigDecimal x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateString(String columnLabel, String x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateBytes(String columnLabel, byte[] x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateDate(String columnLabel, Date x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateTime(String columnLabel, Time x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateTimestamp(String columnLabel, Timestamp x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateAsciiStream(String columnLabel, InputStream x, int length) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateBinaryStream(String columnLabel, InputStream x, int length) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateCharacterStream(String columnLabel, Reader reader, int length) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateObject(String columnLabel, Object x, int scaleOrLength) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateObject(String columnLabel, Object x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void insertRow() throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void updateRow() throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void deleteRow() throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void refreshRow() throws SQLException {
        // Read-only, nothing to refresh
    }
    
    @Override
    public void cancelRowUpdates() throws SQLException {
        // Read-only, nothing to cancel
    }
    
    @Override
    public void moveToInsertRow() throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported in read-only mode");
    }
    
    @Override
    public void moveToCurrentRow() throws SQLException {
        // Read-only, nothing to do
    }
    
    @Override
    public Statement getStatement() throws SQLException {
        return null;
    }
    
    @Override
    public Object getObject(int columnIndex, Map<String, Class<?>> map) throws SQLException {
        return getObject(columnIndex);
    }
    
    @Override
    public Ref getRef(int columnIndex) throws SQLException {
        throw new SQLFeatureNotSupportedException("getRef not supported");
    }
    
    @Override
    public Blob getBlob(int columnIndex) throws SQLException {
        byte[] bytes = getBytes(columnIndex);
        return bytes != null ? new DBFBlob(bytes) : null;
    }
    
    @Override
    public Clob getClob(int columnIndex) throws SQLException {
        String s = getString(columnIndex);
        return s != null ? new DBFClob(s) : null;
    }
    
    @Override
    public Array getArray(int columnIndex) throws SQLException {
        throw new SQLFeatureNotSupportedException("getArray not supported");
    }
    
    @Override
    public Object getObject(String columnLabel, Map<String, Class<?>> map) throws SQLException {
        return getObject(columnLabel);
    }
    
    @Override
    public Ref getRef(String columnLabel) throws SQLException {
        return getRef(findColumn(columnLabel));
    }
    
    @Override
    public Blob getBlob(String columnLabel) throws SQLException {
        return getBlob(findColumn(columnLabel));
    }
    
    @Override
    public Clob getClob(String columnLabel) throws SQLException {
        return getClob(findColumn(columnLabel));
    }
    
    @Override
    public Array getArray(String columnLabel) throws SQLException {
        return getArray(findColumn(columnLabel));
    }
    
    @Override
    public Date getDate(int columnIndex, Calendar cal) throws SQLException {
        Date d = getDate(columnIndex);
        if (d == null || cal == null) return d;
        Calendar c = Calendar.getInstance(cal.getTimeZone());
        c.setTime(d);
        return new Date(c.getTimeInMillis());
    }
    
    @Override
    public Date getDate(String columnLabel, Calendar cal) throws SQLException {
        return getDate(findColumn(columnLabel), cal);
    }
    
    @Override
    public Time getTime(int columnIndex, Calendar cal) throws SQLException {
        Time t = getTime(columnIndex);
        if (t == null || cal == null) return t;
        Calendar c = Calendar.getInstance(cal.getTimeZone());
        c.setTime(t);
        return new Time(c.getTimeInMillis());
    }
    
    @Override
    public Time getTime(String columnLabel, Calendar cal) throws SQLException {
        return getTime(findColumn(columnLabel), cal);
    }
    
    @Override
    public Timestamp getTimestamp(int columnIndex, Calendar cal) throws SQLException {
        Timestamp ts = getTimestamp(columnIndex);
        if (ts == null || cal == null) return ts;
        Calendar c = Calendar.getInstance(cal.getTimeZone());
        c.setTime(ts);
        return new Timestamp(c.getTimeInMillis());
    }
    
    @Override
    public Timestamp getTimestamp(String columnLabel, Calendar cal) throws SQLException {
        return getTimestamp(findColumn(columnLabel), cal);
    }
    
    @Override
    public URL getURL(int columnIndex) throws SQLException {
        throw new SQLFeatureNotSupportedException("getURL not supported");
    }
    
    @Override
    public URL getURL(String columnLabel) throws SQLException {
        throw new SQLFeatureNotSupportedException("getURL not supported");
    }
    
    @Override
    public void updateRef(int columnIndex, Ref x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateRef(String columnLabel, Ref x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateBlob(int columnIndex, Blob x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateBlob(String columnLabel, Blob x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateClob(int columnIndex, Clob x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateClob(String columnLabel, Clob x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateArray(int columnIndex, Array x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateArray(String columnLabel, Array x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public RowId getRowId(int columnIndex) throws SQLException {
        throw new SQLFeatureNotSupportedException("getRowId not supported");
    }
    
    @Override
    public RowId getRowId(String columnLabel) throws SQLException {
        throw new SQLFeatureNotSupportedException("getRowId not supported");
    }
    
    @Override
    public void updateRowId(int columnIndex, RowId x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateRowId(String columnLabel, RowId x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public int getHoldability() throws SQLException {
        return HOLD_CURSORS_OVER_COMMIT;
    }
    
    @Override
    public boolean isClosed() throws SQLException {
        return closed;
    }
    
    @Override
    public void updateNString(int columnIndex, String nString) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateNString(String columnLabel, String nString) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateNClob(int columnIndex, NClob nClob) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateNClob(String columnLabel, NClob nClob) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public NClob getNClob(int columnIndex) throws SQLException {
        String s = getString(columnIndex);
        return s != null ? new DBFNClob(s) : null;
    }
    
    @Override
    public NClob getNClob(String columnLabel) throws SQLException {
        return getNClob(findColumn(columnLabel));
    }
    
    @Override
    public SQLXML getSQLXML(int columnIndex) throws SQLException {
        throw new SQLFeatureNotSupportedException("getSQLXML not supported");
    }
    
    @Override
    public SQLXML getSQLXML(String columnLabel) throws SQLException {
        throw new SQLFeatureNotSupportedException("getSQLXML not supported");
    }
    
    @Override
    public void updateSQLXML(int columnIndex, SQLXML xmlObject) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateSQLXML(String columnLabel, SQLXML xmlObject) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public String getNString(int columnIndex) throws SQLException {
        return getString(columnIndex);
    }
    
    @Override
    public String getNString(String columnLabel) throws SQLException {
        return getString(columnLabel);
    }
    
    @Override
    public Reader getNCharacterStream(int columnIndex) throws SQLException {
        String s = getString(columnIndex);
        return s != null ? new java.io.StringReader(s) : null;
    }
    
    @Override
    public Reader getNCharacterStream(String columnLabel) throws SQLException {
        return getNCharacterStream(findColumn(columnLabel));
    }
    
    @Override
    public void updateNCharacterStream(int columnIndex, Reader x, long length) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateNCharacterStream(String columnLabel, Reader reader, long length) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateAsciiStream(int columnIndex, InputStream x, long length) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateBinaryStream(int columnIndex, InputStream x, long length) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateCharacterStream(int columnIndex, Reader x, long length) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateAsciiStream(String columnLabel, InputStream x, long length) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateBinaryStream(String columnLabel, InputStream x, long length) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateCharacterStream(String columnLabel, Reader reader, long length) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateBlob(int columnIndex, InputStream inputStream, long length) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateBlob(String columnLabel, InputStream inputStream, long length) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateClob(int columnIndex, Reader reader, long length) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateClob(String columnLabel, Reader reader, long length) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateNClob(int columnIndex, Reader reader, long length) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateNClob(String columnLabel, Reader reader, long length) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateNCharacterStream(int columnIndex, Reader x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateNCharacterStream(String columnLabel, Reader reader) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateAsciiStream(int columnIndex, InputStream x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateBinaryStream(int columnIndex, InputStream x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateCharacterStream(int columnIndex, Reader x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateAsciiStream(String columnLabel, InputStream x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateBinaryStream(String columnLabel, InputStream x) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateCharacterStream(String columnLabel, Reader reader) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateBlob(int columnIndex, InputStream inputStream) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateBlob(String columnLabel, InputStream inputStream) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateClob(int columnIndex, Reader reader) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateClob(String columnLabel, Reader reader) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateNClob(int columnIndex, Reader reader) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public void updateNClob(String columnLabel, Reader reader) throws SQLException {
        throw new SQLFeatureNotSupportedException("Updates not supported");
    }
    
    @Override
    public <T> T getObject(int columnIndex, Class<T> type) throws SQLException {
        Object obj = getObject(columnIndex);
        if (type.isInstance(obj)) {
            return type.cast(obj);
        }
        throw new SQLException("Cannot cast " + (obj != null ? obj.getClass() : "null") + " to " + type);
    }
    
    @Override
    public <T> T getObject(String columnLabel, Class<T> type) throws SQLException {
        return getObject(findColumn(columnLabel), type);
    }
    
    @Override
    public <T> T unwrap(Class<T> iface) throws SQLException {
        if (iface.isInstance(this)) {
            return iface.cast(this);
        }
        throw new SQLException("Cannot unwrap to " + iface);
    }
    
    @Override
    public boolean isWrapperFor(Class<?> iface) throws SQLException {
        return iface.isInstance(this);
    }
    
    // Helper methods for BLOB/CLOB support
    private static class DBFBlob implements Blob {
        private final byte[] data;
        private boolean closed = false;
        
        DBFBlob(byte[] data) { this.data = data != null ? data : new byte[0]; }
        
        @Override public long length() { return data.length; }
        @Override public byte[] getBytes(long pos, int length) {
            int start = (int) pos - 1;
            int len = Math.min(length, data.length - start);
            byte[] result = new byte[len];
            System.arraycopy(data, start, result, 0, len);
            return result;
        }
        @Override public InputStream getBinaryStream() { return new java.io.ByteArrayInputStream(data); }
        @Override public long position(byte[] pattern, long start) { return -1; }
        @Override public long position(Blob pattern, long start) { return -1; }
        @Override public int setBytes(long pos, byte[] bytes) { throw new UnsupportedOperationException(); }
        @Override public int setBytes(long pos, byte[] bytes, int offset, int len) { throw new UnsupportedOperationException(); }
        @Override public OutputStream setBinaryStream(long pos) { throw new UnsupportedOperationException(); }
        @Override public void truncate(long len) { }
        @Override public void free() { closed = true; }
        @Override public InputStream getBinaryStream(long pos, long length) { return getBinaryStream(); }
    }
    
    private static class DBFClob implements Clob {
        private final String data;
        private boolean closed = false;
        
        DBFClob(String data) { this.data = data != null ? data : ""; }
        
        @Override public long length() { return data.length(); }
        @Override public String getSubString(long pos, int length) {
            return data.substring((int) pos - 1, Math.min((int) pos - 1 + length, data.length()));
        }
        @Override public Reader getCharacterStream() { return new java.io.StringReader(data); }
        @Override public InputStream getAsciiStream() { return new java.io.ByteArrayInputStream(data.getBytes()); }
        @Override public long position(String searchstr, long start) { return data.indexOf(searchstr, (int) start - 1) + 1; }
        @Override public long position(Clob searchstr, long start) { 
        	try {
			return position(searchstr.getSubString(1, (int) searchstr.length()), start);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return start; }
        @Override public int setString(long pos, String str) { throw new UnsupportedOperationException(); }
        @Override public int setString(long pos, String str, int offset, int len) { throw new UnsupportedOperationException(); }
        @Override public OutputStream setAsciiStream(long pos) { throw new UnsupportedOperationException(); }
        @Override public Writer setCharacterStream(long pos) { throw new UnsupportedOperationException(); }
        @Override public void truncate(long len) { }
        @Override public void free() { closed = true; }
        @Override public Reader getCharacterStream(long pos, long length) { return getCharacterStream(); }
    }
    
    private static class DBFNClob extends DBFClob implements NClob {
        DBFNClob(String data) { super(data); }
    }
    
//    public void setFetchSize(int size) {
//        this.fetchSize = size;
//    }
    
    public int getTotalRows() {
        return totalRows;
    }
/////////////////////////////////////////////////////////////
//////////////////////////////////////////
  
	@Override
	public BigDecimal getBigDecimal(int columnIndex) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BigDecimal getBigDecimal(String columnLabel) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Reader getCharacterStream(int columnIndex) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Reader getCharacterStream(String columnLabel) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public InputStream getUnicodeStream(int columnIndex) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public InputStream getUnicodeStream(String columnLabel) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
}